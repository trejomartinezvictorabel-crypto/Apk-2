// Copia embebida de scripts/autoreparar_app.py: la app la guarda en Descargas con un toque (Diagnóstico → Autoreparación).
// Se genera a partir del archivo del repositorio; si cambias uno, cambia el otro.
const String kScriptAutoreparar = r'''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
autoreparar_app.py  ·  Navegación Offline

Lee el reporte que genera la app (Diagnóstico -> Autoreparación -> «NO REPARADO EN EL TELÉFONO / REQUIERE
COMPILACIÓN», guardado como reporte_autoreparacion.json) y aplica sobre el código fuente lo que el teléfono no
puede resolver solo, antes de compilar el APK:

  clave            qué hace este script
  ---------------  ---------------------------------------------------------------------------------------------
  android16        compileSdk/targetSdk 36, permisos del manifiesto, desugaring (notificaciones locales)
  paquetes         sube en pubspec.yaml los paquetes desactualizados (misma versión mayor, compatible)
  paquete_mayor    NO sube versiones mayores solas (pueden romper la compilación): lo deja anotado
  vosk_modelo      verifica/rehace el modelo Vosk de assets y actualiza la tabla de «últimos modelos» de la app
  archivo_danado,  son archivos de TU teléfono (mapas, zips, bases): el script no los toca; deja la instrucción
  base_datos,
  indice,
  permiso_archivos,
  paso_fallido

También hace SIEMPRE (idempotente, aunque no haya reporte) las comprobaciones de estructura y de compatibilidad con
Android 16, para que el proyecto quede listo para generar el APK.

Uso:
  python3 scripts/autoreparar_app.py                                   (sin reporte: solo lo obligatorio)
  python3 scripts/autoreparar_app.py --reporte scripts/reporte_autoreparacion.json
  python3 scripts/autoreparar_app.py --reporte ... --simular           (no escribe nada, solo dice qué haría)
  python3 scripts/autoreparar_app.py --sin-red                         (no consulta internet)

Código de salida: 0 = listo para compilar · 1 = falta algo imprescindible del proyecto.
Escribe reporte_autoreparar.txt en la raíz (el flujo de trabajo lo sube como artefacto).
"""
import argparse
import json
import os
import re
import sys
import urllib.request

LOG = []


def log(t=""):
    print(t)
    LOG.append(str(t))


class Ctx:
    def __init__(self, raiz, simular, sin_red):
        self.raiz = raiz
        self.simular = simular
        self.sin_red = sin_red
        self.cambios = []
        self.avisos = []
        self.manuales = []

    def ruta(self, *p):
        return os.path.join(self.raiz, *p)

    def leer(self, *p):
        r = self.ruta(*p)
        if not os.path.exists(r):
            return None
        with open(r, encoding="utf-8") as f:
            return f.read()

    def escribir(self, texto, *p):
        if self.simular:
            log("  [simulación] escribiría " + "/".join(p))
            return
        with open(self.ruta(*p), "w", encoding="utf-8") as f:
            f.write(texto)


def version_de(t):
    return [int(x) for x in re.findall(r"\d+", t)[:4]] or [0]


# --------------------------------------------------------------------------- estructura
def estructura(c):
    log("== 1. Estructura del proyecto ==")
    falta = False
    for r in ["lib/main.dart", "lib/traducciones.dart", "pubspec.yaml", "android/app/build.gradle"]:
        ok = os.path.exists(c.ruta(*r.split("/")))
        log("  [%s] %s" % ("OK" if ok else "FALTA", r))
        if not ok:
            falta = True
    main = c.leer("lib", "main.dart") or ""
    for m in re.findall(r"^(?:part|import) '([a-z_]+\.dart)';", main, flags=re.M):
        ok = os.path.exists(c.ruta("lib", m))
        log("  [%s] lib/%s (lo usa main.dart)" % ("OK" if ok else "FALTA", m))
        if not ok:
            falta = True
    return not falta


# --------------------------------------------------------------------------- pubspec
def pubspec(c, reporte):
    log("== 2. Paquetes (pubspec.yaml) ==")
    t = c.leer("pubspec.yaml")
    if t is None:
        log("  pubspec.yaml aún no existe (se crea en el paso 1 del flujo de trabajo): nada que hacer")
        return
    original = t
    obligatorios = {"dartssh2": "^2.9.0", "flutter_local_notifications": "^17.2.4"}
    for nombre, ver in obligatorios.items():
        if not re.search(r"(?m)^  %s:" % re.escape(nombre), t):
            t = re.sub(r"(?m)^(dependencies:\s*\n(?:  .*\n)+?)(\n|dev_dependencies)", lambda m: m.group(1) + "  %s: %s\n" % (nombre, ver) + m.group(2), t, count=1)
            c.cambios.append("pubspec.yaml: agregado %s %s" % (nombre, ver))
            log("  + %s %s" % (nombre, ver))
    for p in reporte.get("paquetes_desactualizados", []):
        nombre, actual, ultima = p.get("nombre"), p.get("actual", ""), p.get("ultima", "")
        if not nombre or not ultima:
            continue
        if p.get("mayor") == "si":
            c.manuales.append("%s %s -> %s es un salto de versión MAYOR: revisa la migración antes de subirlo (no se cambió)." % (nombre, actual, ultima))
            log("  ! %s: salto mayor (%s -> %s): solo anotado" % (nombre, actual, ultima))
            continue
        nuevo = re.sub(r"(?m)^(  %s:\s*)\^?[\d.+\w-]+\s*$" % re.escape(nombre), r"\g<1>^%s" % ultima, t)
        if nuevo != t:
            t = nuevo
            c.cambios.append("pubspec.yaml: %s %s -> ^%s" % (nombre, actual, ultima))
            log("  ^ %s %s -> ^%s" % (nombre, actual, ultima))
    if t != original:
        c.escribir(t, "pubspec.yaml")
    else:
        log("  sin cambios")


# --------------------------------------------------------------------------- Android 16
def android16(c):
    log("== 3. Android 16 (SDK 36), notificaciones y manifiesto ==")
    ruta = ("android", "app", "build.gradle")
    t = c.leer(*ruta)
    if t is not None:
        o = t
        t = re.sub(r"(?m)^(\s*)compileSdk(?:Version)?\s+\S+", r"\1compileSdk 36", t)
        t = re.sub(r"(?m)^(\s*)targetSdk(?:Version)?\s+\S+", r"\1targetSdk 36", t)
        if "coreLibraryDesugaringEnabled" not in t:
            if re.search(r"compileOptions\s*\{", t):
                t = re.sub(r"(compileOptions\s*\{\s*\n)", r"\1        coreLibraryDesugaringEnabled true\n", t, count=1)
            else:
                t = re.sub(r"(?m)^(android\s*\{\s*\n)", r"\1    compileOptions {\n        coreLibraryDesugaringEnabled true\n        sourceCompatibility JavaVersion.VERSION_17\n        targetCompatibility JavaVersion.VERSION_17\n    }\n", t, count=1)
            c.cambios.append("build.gradle: coreLibraryDesugaringEnabled true")
        if "desugar_jdk_libs" not in t:
            dep = "    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n"
            if re.search(r"(?m)^dependencies\s*\{", t):
                t = re.sub(r"(?m)^(dependencies\s*\{\s*\n)", r"\1" + dep, t, count=1)
            else:
                t += "\ndependencies {\n" + dep + "}\n"
            c.cambios.append("build.gradle: dependencia desugar_jdk_libs 2.1.4")
        if t != o:
            c.escribir(t, *ruta)
            log("  build.gradle actualizado")
        else:
            log("  build.gradle ya estaba al día")
    m = c.leer("android", "app", "src", "main", "AndroidManifest.xml")
    if m is not None:
        faltan = []
        for perm in ["INTERNET", "ACCESS_FINE_LOCATION", "FOREGROUND_SERVICE", "FOREGROUND_SERVICE_LOCATION", "POST_NOTIFICATIONS", "RECORD_AUDIO", "WAKE_LOCK"]:
            if "android.permission.%s" % perm not in m:
                faltan.append(perm)
        if faltan and "<application" in m:
            bloque = "".join('    <uses-permission android:name="android.permission.%s"/>\n' % p for p in faltan)
            m = m.replace("<application", bloque + "    <application", 1)
            c.escribir(m, "android", "app", "src", "main", "AndroidManifest.xml")
            c.cambios.append("AndroidManifest.xml: permisos agregados " + ", ".join(faltan))
            log("  permisos agregados: " + ", ".join(faltan))
        else:
            log("  manifiesto con todos los permisos")
    log("  Nota 16 KB: Flutter 3.27 + AGP 8.3.2 alinean las bibliotecas; el paso 8 del flujo lo comprueba en el APK.")


# --------------------------------------------------------------------------- Vosk
def existe_url(url):
    try:
        rq = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "autoreparar_app"})
        with urllib.request.urlopen(rq, timeout=25) as r:
            return 200 <= r.status < 400
    except Exception:
        return False


def vosk(c, reporte):
    log("== 4. Modelo de voz Vosk ==")
    zip_es = c.ruta("assets", "models", "vosk-model-small-es-0.42.zip")
    if os.path.exists(zip_es) and os.path.getsize(zip_es) < 1000000 and not c.sin_red and not c.simular:
        log("  el modelo de assets está incompleto: se vuelve a descargar")
        try:
            urllib.request.urlretrieve("https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip", zip_es)
            c.cambios.append("assets: modelo Vosk es descargado de nuevo")
        except Exception as e:
            c.manuales.append("No se pudo volver a descargar el modelo Vosk de assets: %s" % e)
    conocidos = reporte.get("modelos_voz_conocidos", {})
    if not conocidos:
        log("  el reporte no trae modelos conocidos: nada que comparar")
        return
    ruta = ("lib", "auditoria.dart")
    t = c.leer(*ruta)
    if t is None:
        return
    m = re.search(r"// AUTO:VOSK_MODELOS_BEGIN\n(.*?)// AUTO:VOSK_MODELOS_END", t, flags=re.S)
    if not m:
        log("  no encontré el bloque AUTO:VOSK_MODELOS en lib/auditoria.dart")
        return
    actuales = dict(re.findall(r"'([a-z]{2})':\s*'([^']+)'", m.group(1)))
    nuevos = dict(actuales)
    if not c.sin_red:
        for idioma, modelo in actuales.items():
            base = re.sub(r"-\d+(?:\.\d+)*$", "", modelo)
            # candidatos: siguientes 6 versiones menores (0.22 -> 0.23 ... 0.28); se acepta la más nueva que exista
            partes = modelo[len(base) + 1:].split(".")
            if len(partes) == 2 and all(x.isdigit() for x in partes):
                mayor, menor = int(partes[0]), int(partes[1])
                for n in range(menor + 6, menor, -1):
                    cand = "%s-%d.%d" % (base, mayor, n)
                    if existe_url("https://alphacephei.com/vosk/models/%s.zip" % cand):
                        nuevos[idioma] = cand
                        break
    cambios = {k: (actuales[k], v) for k, v in nuevos.items() if v != actuales[k]}
    if not cambios:
        log("  los modelos conocidos siguen siendo los últimos verificados")
        return
    cuerpo = "const Map<String, String> kVoskUltimos = <String, String>{\n" + "".join("  '%s': '%s',\n" % kv for kv in nuevos.items()) + "};\n"
    t = t[: m.start(1)] + cuerpo + t[m.end(1):]
    c.escribir(t, *ruta)
    for k, (a, b) in cambios.items():
        c.cambios.append("Vosk %s: %s -> %s (tabla de la app)" % (k, a, b))
        log("  Vosk %s: %s -> %s" % (k, a, b))
    c.manuales.append("El modelo Vosk de assets sigue siendo el de español del flujo de trabajo; los nuevos se ofrecen para descargar dentro de la app.")


# --------------------------------------------------------------------------- pendientes del teléfono
def pendientes(c, reporte):
    log("== 5. Pendientes que reportó el teléfono ==")
    ps = reporte.get("pendientes", [])
    if not ps:
        log("  (ninguno)")
        return
    gestionadas = {"android16", "paquetes", "paquete_mayor", "vosk_modelo"}
    for p in ps:
        clave = p.get("clave", "")
        estado = "aplicado por este script" if clave in gestionadas else "ACCIÓN DEL USUARIO en el teléfono"
        log("  • [%s] %s: %s" % (clave, p.get("modulo", ""), p.get("motivo", "")))
        log("      %s -> %s" % (estado, p.get("accion", "")))
        if clave not in gestionadas:
            c.manuales.append("[%s] %s: %s -> %s" % (clave, p.get("modulo", ""), p.get("motivo", ""), p.get("accion", "")))


def main():
    ap = argparse.ArgumentParser(description="Autoreparación del proyecto Navegación Offline antes de compilar")
    ap.add_argument("--reporte", help="reporte_autoreparacion.json generado por la app")
    ap.add_argument("--raiz", default=".", help="raíz del proyecto (por omisión, la carpeta actual)")
    ap.add_argument("--simular", action="store_true", help="no escribe nada")
    ap.add_argument("--sin-red", action="store_true", help="no consulta internet")
    a = ap.parse_args()
    c = Ctx(os.path.abspath(a.raiz), a.simular, a.sin_red)
    reporte = {}
    ruta = a.reporte
    if not ruta:
        for cand in ("scripts/reporte_autoreparacion.json", "reporte_autoreparacion.json"):
            if os.path.exists(os.path.join(c.raiz, cand)):
                ruta = os.path.join(c.raiz, cand)
                break
    if ruta and os.path.exists(ruta):
        try:
            with open(ruta, encoding="utf-8") as f:
                reporte = json.load(f)
            log("Reporte leído: %s (fecha %s, %d pendientes)" % (ruta, reporte.get("fecha", "?"), len(reporte.get("pendientes", []))))
        except Exception as e:
            log("AVISO: no pude leer el reporte (%s); se aplican solo las comprobaciones obligatorias" % e)
    else:
        log("Sin reporte: se aplican solo las comprobaciones obligatorias")
    if a.simular:
        log("MODO SIMULACIÓN: no se escribe nada")
    ok = estructura(c)
    pubspec(c, reporte)
    android16(c)
    vosk(c, reporte)
    pendientes(c, reporte)
    log("")
    log("== RESUMEN ==")
    log("Cambios aplicados: %d" % len(c.cambios))
    for x in c.cambios:
        log("  + " + x)
    if c.manuales:
        log("Pendiente de tu parte / revisión manual:")
        for x in c.manuales:
            log("  ! " + x)
    log("Proyecto listo para compilar: %s" % ("SÍ" if ok else "NO (falta algo imprescindible)"))
    if not a.simular:
        try:
            with open(c.ruta("reporte_autoreparar.txt"), "w", encoding="utf-8") as f:
                f.write("\n".join(LOG) + "\n")
        except Exception:
            pass
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
''';
