#!/usr/bin/env python3
"""Validador del proyecto. Uso:  python3 scripts/validar_proyecto.py antes   (antes de compilar)
                                python3 scripts/validar_proyecto.py despues (después de compilar el APK)
Imprime ✔ / ⚠ / ✘ por revisión. Termina con código 1 si hay algún ✘."""
import glob, os, re, struct, sys, zipfile
import xml.etree.ElementTree as ET

OK, AV, ER = [], [], []
def ok(m): OK.append(m); print('  ✔', m)
def av(m): AV.append(m); print('  ⚠', m)
def er(m): ER.append(m); print('  ✘', m)
def sec(t): print('\n== ' + t)
def leer(p):
    with open(p, encoding='utf-8', errors='replace') as f: return f.read()

PERMISOS = ['INTERNET','ACCESS_FINE_LOCATION','ACCESS_COARSE_LOCATION','FOREGROUND_SERVICE','FOREGROUND_SERVICE_LOCATION',
            'RECORD_AUDIO','POST_NOTIFICATIONS','WAKE_LOCK','MANAGE_EXTERNAL_STORAGE','READ_EXTERNAL_STORAGE']
DENS = {'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}

def png_dim(p):
    with open(p,'rb') as f: h=f.read(24)
    if h[:8]!=b'\x89PNG\r\n\x1a\n': return None
    return struct.unpack('>II',h[16:24])

def antes():
    sec('Código')
    if os.path.isfile('lib/main.dart'):
        c = leer('lib/main.dart')
        ok(f'lib/main.dart presente ({len(c.splitlines())} líneas)')
        if 'void main(' in c: ok('contiene void main()')
        else: er('lib/main.dart no tiene void main()')
    else:
        er('falta lib/main.dart'); c = ''
    sec('pubspec.yaml')
    if os.path.isfile('pubspec.yaml'):
        ps = leer('pubspec.yaml'); ok('pubspec.yaml presente')
        m = re.search(r'^dependencies:\n(.*?)^\S', ps + '\nx', re.S | re.M)
        deps = re.findall(r'^\s{2}([a-z_0-9]+):', m.group(1), re.M) if m else []
        for d in deps:
            if d == 'flutter': continue
            if c and not re.search(r"package:%s/" % d, c): av(f'dependencia «{d}» declarada pero main.dart no la importa (se puede quitar)')
        for imp in sorted(set(re.findall(r"import 'package:([a-z_0-9]+)/", c))):
            if imp not in deps and imp != 'flutter': er(f'main.dart importa «{imp}» pero no está en pubspec.yaml')
        mv = re.search(r'^version:\s*(\S+)', ps, re.M)
        ok(f'versión {mv.group(1)}') if mv else er('pubspec sin version')
    else: er('falta pubspec.yaml')
    zips = glob.glob('assets/models/*.zip') + glob.glob('assets/models/*')
    if any(os.path.getsize(z) > 1_000_000 for z in zips if os.path.isfile(z)): ok('modelo de voz (Vosk) presente en assets/models')
    else: er('no hay modelo de voz > 1 MB en assets/models (la voz offline no funcionará)')

    sec('AndroidManifest.xml')
    mp = 'android/app/src/main/AndroidManifest.xml'
    if not os.path.isfile(mp): er('falta ' + mp)
    else:
        t = leer(mp)
        try: ET.fromstring(t); ok('XML válido')
        except ET.ParseError as e: er(f'XML inválido: {e}')
        for p in PERMISOS:
            n = t.count(f'android.permission.{p}"')
            if n == 1: ok(f'permiso {p}')
            elif n == 0: er(f'falta el permiso {p}')
            else: av(f'permiso {p} repetido {n} veces')
        for a, v in (('android:label', 'Navegación Offline'), ('android:icon', '@mipmap/ic_launcher'), ('android:roundIcon', '@mipmap/ic_launcher_round')):
            if f'{a}="{v}"' in t: ok(f'{a} = {v}')
            else: er(f'{a} no es «{v}»')
        if '${applicationName}' in t and 'MainActivity' in t: ok('actividad principal y applicationName intactos')
        else: er('el manifiesto perdió MainActivity o ${applicationName}')
    sec('Íconos')
    base = 'android/app/src/main/res'
    for d, px in DENS.items():
        for n in ('ic_launcher', 'ic_launcher_round'):
            f = f'{base}/mipmap-{d}/{n}.png'
            dim = png_dim(f) if os.path.isfile(f) else None
            if dim == (px, px): ok(f'{n} {d} {px}px')
            else: er(f'{f}: falta o tamaño incorrecto ({dim}, se esperaba {px}×{px})')
        f = f'{base}/mipmap-{d}/ic_launcher_foreground.png'
        dim = png_dim(f) if os.path.isfile(f) else None
        if dim and dim[0] == dim[1]: ok(f'foreground {d} {dim[0]}px')
        else: er(f'{f}: falta o no es cuadrado')
    for f in (f'{base}/mipmap-anydpi-v26/ic_launcher.xml', f'{base}/mipmap-anydpi-v26/ic_launcher_round.xml', f'{base}/values/ic_launcher_colors.xml'):
        ok(os.path.basename(f)) if os.path.isfile(f) else er('falta ' + f)
    sec('Gradle / SDK')
    g = next((p for p in ('android/app/build.gradle', 'android/app/build.gradle.kts') if os.path.isfile(p)), None)
    if g:
        t = leer(g)
        for k in ('compileSdk', 'targetSdk', 'minSdk'):
            m = re.search(k + r'(?:Version)?\s*[= ]\s*(\d+)', t)
            ok(f'{k} = {m.group(1)}') if m else av(f'no encuentro {k} en {g}')
    else: er('falta android/app/build.gradle')
    if os.path.isfile('android/app/ci-keystore.p12'): ok('llave de firma fija presente (ci-keystore.p12)')
    else: er('falta android/app/ci-keystore.p12: sin ella cada APK se firma distinto y no se instala encima del anterior')
    if g and 'ci-keystore.p12' in leer(g): ok('build.gradle usa la firma fija')
    else: er('build.gradle no usa la firma fija (falló el paso 3c)')
    w = 'android/gradle/wrapper/gradle-wrapper.properties'
    if os.path.isfile(w) and 'gradle-8.10.2' in leer(w): ok('Gradle 8.10.2')
    else: av('Gradle wrapper no es 8.10.2')

def elf_alineacion(datos):
    """Menor alineación de los segmentos PT_LOAD de un .so de 64 bits (Android 15 pide ≥ 16384 = 16 KB)."""
    if datos[:4] != b'\x7fELF' or datos[4] != 2: return None
    phoff = struct.unpack_from('<Q', datos, 0x20)[0]
    phentsize, phnum = struct.unpack_from('<HH', datos, 0x36)
    mn = None
    for i in range(phnum):
        o = phoff + i * phentsize
        tipo = struct.unpack_from('<I', datos, o)[0]
        if tipo == 1:
            al = struct.unpack_from('<Q', datos, o + 48)[0]
            mn = al if mn is None else min(mn, al)
    return mn

def despues():
    sec('APK')
    apks = glob.glob('build/app/outputs/flutter-apk/*.apk')
    if not apks: er('no se generó ningún APK'); return
    apk = apks[0]; mb = os.path.getsize(apk) / 1048576
    ok(f'{os.path.basename(apk)} ({mb:.1f} MB)')
    z = zipfile.ZipFile(apk); nombres = z.namelist()
    if any(n.startswith('lib/arm64-v8a/') for n in nombres): ok('incluye arm64-v8a (tu Galaxy A06)')
    else: er('el APK no incluye arm64-v8a')
    if any('assets/models' in n or 'vosk' in n.lower() for n in nombres): ok('modelo de voz empaquetado')
    else: av('no veo el modelo de voz en el APK')
    if any(re.match(r'res/mipmap.*/ic_launcher', n) or 'ic_launcher' in n for n in nombres): ok('íconos empaquetados')
    else: er('no hay íconos ic_launcher en el APK')
    sec('Firma del APK (debe ser SIEMPRE la misma para poder actualizar encima)')
    try:
        import subprocess
        salida = subprocess.run(['keytool', '-printcert', '-jarfile', apk], capture_output=True, text=True, timeout=60).stdout
        m = re.search(r'SHA256:\s*([0-9A-F:]+)', salida)
        if m: ok('huella SHA-256 de la firma: ' + m.group(1) + ' (si cambia entre compilaciones, no podrás actualizar encima)')
        else: av('no pude leer la firma del APK')
    except Exception as e:
        av('no pude leer la firma del APK: ' + str(e))
    sec('Manifiesto final (con los plugins)')
    mf = glob.glob('build/app/intermediates/merged_manifests/**/AndroidManifest.xml', recursive=True) or glob.glob('build/app/intermediates/packaged_manifests/**/AndroidManifest.xml', recursive=True)
    if mf:
        t = leer(mf[0])
        ok('servicio de ubicación declarado (foregroundServiceType=location)') if 'foregroundServiceType="location"' in t else av('no veo un servicio con foregroundServiceType="location" (revisa geolocator)')
        ok('applicationId ' + re.search(r'package="([^"]+)"', t).group(1)) if re.search(r'package="([^"]+)"', t) else None
    else: av('no encontré el manifiesto combinado')
    sec('Páginas de 16 KB (Android 15+, requisito de Google Play)')
    malas = []; total = 0
    for n in nombres:
        if n.endswith('.so') and '/arm64-v8a/' in n or n.endswith('.so') and '/x86_64/' in n:
            total += 1
            al = elf_alineacion(z.read(n))
            if al is not None and al < 16384: malas.append((n, al))
    if total == 0: av('no hay librerías nativas de 64 bits que revisar')
    elif not malas: ok(f'{total} librerías nativas de 64 bits alineadas a 16 KB')
    else:
        for n, al in malas: av(f'{n}: alineación {al} (<16384) → no cumple 16 KB; actualiza o quita el paquete que la trae')

if __name__ == '__main__':
    modo = sys.argv[1] if len(sys.argv) > 1 else 'antes'
    print('VALIDACIÓN (' + modo + ')')
    (antes if modo == 'antes' else despues)()
    print(f'\nRESUMEN: {len(OK)} bien · {len(AV)} avisos · {len(ER)} errores')
    sys.exit(1 if ER else 0)
