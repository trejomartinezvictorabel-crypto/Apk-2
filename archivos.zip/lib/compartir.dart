// ============================================================================
// COMPARTIR MI UBICACIÓN EN TIEMPO REAL (parte de main.dart)
// ----------------------------------------------------------------------------
//  • Servidor HTTP ligero DENTRO del teléfono: sirve una página con mapa y un JSON mínimo de posición.
//  • Enlace por internet temporal: un túnel SSH inverso (localhost.run) abre una dirección https pública que
//    apunta a ese servidor. Sin servidores míos. Si el túnel no se puede abrir, queda el enlace de la misma Wi‑Fi.
//  • Token aleatorio nuevo en CADA activación; al vencer o al finalizar, el servidor y el túnel se cierran y el
//    enlace deja de funcionar.
//  • Bajo consumo de datos: solo se publican coordenadas (lat, lon, precisión, hora, estado), nunca imágenes de
//    mapa; no se publica si no te moviste lo suficiente; el visor espera con «long-polling» (sin consultas vacías).
// ============================================================================
part of 'main.dart';

enum ModoCompartir { ahorro, normal }

class CompartirUbicacion extends ChangeNotifier {
  final Controlador c;
  CompartirUbicacion(this.c);

  HttpServer? _srv;
  ssh.SSHClient? _ssh;
  Timer? _tick, _tRed;
  String? token;
  String? urlLocal, urlRemota;
  DateTime? vence;
  ModoCompartir modo = ModoCompartir.ahorro;
  bool activo = false, conInternet = true, _tunelEnCurso = false;
  String estadoTunel = '';
  int _version = 0, _ultimoMs = 0;
  Position? _ultimoEnviado;
  Map<String, Object?> _ultimo = <String, Object?>{};
  final List<Completer<void>> _esperando = <Completer<void>>[];

  int? get segundosRestantes => vence == null ? null : math.max(0, vence!.difference(DateTime.now()).inSeconds);

  // ---------------------------------------------------- red
  Future<void> revisarRed() async {
    final antes = conInternet;
    conInternet = await c.hayInternet();
    if (conInternet != antes) {
      Registro.anotar(conInternet ? 'Compartir ubicación: internet recuperado' : 'Compartir ubicación: SIN internet');
      if (conInternet && activo && urlRemota == null) unawaited(_abrirTunel());
    }
    notifyListeners();
  }

  Future<String?> _ipLocal() async {
    try {
      for (final i in await NetworkInterface.list(type: InternetAddressType.IPv4)) {
        for (final a in i.addresses) {
          if (!a.isLoopback) return a.address;
        }
      }
    } catch (_) {}
    return null;
  }

  // ---------------------------------------------------- activar / finalizar
  /// [duracion] null = hasta que lo finalices a mano.
  Future<void> iniciar(Duration? duracion) async {
    if (activo) await finalizar(aviso: false); // cada activación = servidor, token y dirección NUEVOS
    final r = math.Random.secure();
    token = base64Url.encode(List<int>.generate(24, (_) => r.nextInt(256))).replaceAll('=', '');
    _version = 0;
    _ultimo = <String, Object?>{};
    _ultimoEnviado = null;
    _ultimoMs = 0;
    urlRemota = null;
    estadoTunel = '';
    await revisarRed();
    try {
      _srv = await HttpServer.bind(InternetAddress.anyIPv4, 0);
    } catch (e) {
      token = null;
      c._msg('No se pudo iniciar el servidor local: $e');
      return;
    }
    _srv!.listen(_atender, onError: (_) {});
    final ip = await _ipLocal();
    urlLocal = ip == null ? null : 'http://$ip:${_srv!.port}/$token';
    vence = duracion == null ? null : DateTime.now().add(duracion);
    activo = true;
    c.compartiendo = true;
    await c.iniciarGps(reiniciar: true); // GPS en primer plano: sigue con la pantalla apagada
    c.addListener(_alUbicacion);
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      final s = segundosRestantes;
      if (s != null && s <= 0) {
        unawaited(finalizar(aviso: true, vencido: true));
        return;
      }
      notifyListeners();
    });
    _tRed = Timer.periodic(const Duration(seconds: 15), (_) => unawaited(revisarRed()));
    final u = c.ubic;
    if (u != null) _publicar(u, forzar: true);
    notifyListeners();
    if (conInternet) {
      unawaited(_abrirTunel());
    } else {
      estadoTunel = 'Sin conexión a internet — el enlace remoto no funcionará desde otra red.';
    }
    Registro.anotar('Compartir ubicación: activado (${duracion == null ? 'manual' : '${duracion.inMinutes} min'}, modo ${modo.name})');
  }

  Future<void> finalizar({bool aviso = true, bool vencido = false}) async {
    if (!activo && _srv == null) return;
    activo = false;
    _tick?.cancel();
    _tRed?.cancel();
    c.removeListener(_alUbicacion);
    _ultimo = <String, Object?>{'fin': true};
    _version++;
    _liberar();
    final srv = _srv, cli = _ssh;
    _srv = null;
    _ssh = null;
    token = null; // el enlace queda revocado
    urlLocal = null;
    urlRemota = null;
    vence = null;
    estadoTunel = '';
    try {
      await srv?.close(force: true);
    } catch (_) {}
    try {
      cli?.close();
    } catch (_) {}
    c.compartiendo = false;
    unawaited(c.iniciarGps(reiniciar: true)); // quita la notificación fija si ya no hace falta
    notifyListeners();
    if (aviso) c._msg(vencido ? 'El enlace de ubicación venció y dejó de funcionar.' : 'Enlace de ubicación finalizado.');
    Registro.anotar('Compartir ubicación: ${vencido ? 'vencido' : 'finalizado'}');
  }

  // ---------------------------------------------------- publicar posiciones (mínimo de datos)
  void _alUbicacion() {
    final u = c.ubic;
    if (u != null && activo) _publicar(u);
  }

  void _publicar(Position u, {bool forzar = false}) {
    final ahora = DateTime.now().millisecondsSinceEpoch;
    final prev = _ultimoEnviado;
    final mov = prev == null ? 1e9 : Geo.dist(prev.latitude, prev.longitude, u.latitude, u.longitude);
    final parado = u.speed < 1.0 && mov < 25;
    final umbral = modo == ModoCompartir.ahorro ? 60.0 : 15.0; // metros
    final latido = modo == ModoCompartir.ahorro ? (parado ? 300000 : 120000) : (parado ? 60000 : 20000); // ms
    if (!forzar && prev != null && mov < umbral && ahora - _ultimoMs < latido) return; // sin cambio relevante: no se envía
    _ultimoEnviado = u;
    _ultimoMs = ahora;
    _version++;
    _ultimo = <String, Object?>{
      'v': _version,
      'lat': double.parse(u.latitude.toStringAsFixed(5)),
      'lon': double.parse(u.longitude.toStringAsFixed(5)),
      'prec': u.accuracy.round(),
      't': DateTime.now().toIso8601String(),
      'estado': parado ? 'detenido' : 'en movimiento',
      'modo': modo.name,
      'vence': vence?.toIso8601String(),
    };
    _liberar();
  }

  void _liberar() {
    for (final w in List<Completer<void>>.of(_esperando)) {
      if (!w.isCompleted) w.complete();
    }
    _esperando.clear();
  }

  // ---------------------------------------------------- servidor
  Future<void> _atender(HttpRequest r) async {
    try {
      final seg = r.uri.pathSegments;
      final t = token;
      if (t == null || seg.isEmpty || seg.first != t) {
        r.response.statusCode = HttpStatus.notFound;
        await r.response.close();
        return;
      }
      r.response.headers
        ..set('Cache-Control', 'no-store')
        ..set('X-Robots-Tag', 'noindex')
        ..set('Referrer-Policy', 'no-referrer');
      if (seg.length == 1) {
        r.response.headers.contentType = ContentType.html;
        r.response.write(_pagina);
        await r.response.close();
        return;
      }
      if (seg[1] == 'pos') {
        final v = int.tryParse(r.uri.queryParameters['v'] ?? '') ?? -1;
        if (_version <= v && activo) {
          final w = Completer<void>();
          _esperando.add(w);
          // Espera hasta que haya un dato nuevo (no se gastan datos en consultas vacías)
          await w.future.timeout(Duration(seconds: modo == ModoCompartir.ahorro ? 55 : 25), onTimeout: () {});
          _esperando.remove(w);
        }
        r.response.headers.contentType = ContentType.json;
        r.response.write(jsonEncode(_version <= v && activo ? <String, Object?>{'v': v, 'igual': true} : _ultimo));
        await r.response.close();
        return;
      }
      r.response.statusCode = HttpStatus.notFound;
      await r.response.close();
    } catch (_) {
      try {
        await r.response.close();
      } catch (_) {}
    }
  }

  // ---------------------------------------------------- enlace por internet (túnel SSH inverso)
  Future<void> _abrirTunel() async {
    if (_tunelEnCurso || !activo || _srv == null) return;
    _tunelEnCurso = true;
    estadoTunel = 'Abriendo el enlace por internet…';
    notifyListeners();
    try {
      final socket = await ssh.SSHSocket.connect('localhost.run', 22, timeout: const Duration(seconds: 15));
      final cli = ssh.SSHClient(socket, username: 'nokey', onPasswordRequest: () => '');
      _ssh = cli;
      await cli.authenticated.timeout(const Duration(seconds: 15));
      final fwd = await cli.forwardRemote(port: 80);
      if (fwd == null) throw Exception('el servicio no aceptó el reenvío de puerto');
      final srv = _srv;
      fwd.connections.listen((ch) async {
        try {
          final local = await Socket.connect(InternetAddress.loopbackIPv4, srv!.port);
          ch.stream.listen(local.add, onDone: local.close, onError: (Object _) => local.destroy());
          local.listen(ch.sink.add, onDone: () => ch.sink.close(), onError: (Object _) => ch.destroy());
        } catch (_) {
          ch.destroy();
        }
      });
      final sesion = await cli.shell();
      final url = Completer<String>();
      sesion.stdout.cast<List<int>>().transform(utf8.decoder).listen((t) {
        final m = RegExp(r'https://[A-Za-z0-9.-]+\.(?:lhr\.life|localhost\.run)').firstMatch(t);
        if (m != null && !url.isCompleted) url.complete(m.group(0));
      }, onError: (Object _) {});
      final u = await url.future.timeout(const Duration(seconds: 25));
      urlRemota = '$u/$token';
      estadoTunel = 'Enlace por internet activo.';
      Registro.anotar('Compartir ubicación: enlace remoto abierto');
      cli.done.then((_) {
        if (activo && identical(_ssh, cli)) {
          urlRemota = null;
          estadoTunel = 'Se cortó el enlace por internet; reintentando…';
          notifyListeners();
          Future<void>.delayed(const Duration(seconds: 8), () {
            if (activo && conInternet) unawaited(_abrirTunel());
          });
        }
      }).catchError((Object _) {});
    } catch (e) {
      urlRemota = null;
      estadoTunel = 'No se pudo abrir el enlace por internet ($e). Mientras tanto funciona en la misma red Wi‑Fi.';
      Registro.anotar('Compartir ubicación: túnel falló: $e');
      try {
        _ssh?.close();
      } catch (_) {}
      _ssh = null;
    } finally {
      _tunelEnCurso = false;
      notifyListeners();
    }
  }

  static const String _pagina = '''<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">
<title>Ubicación en tiempo real</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>html,body{height:100%;margin:0;font-family:system-ui,sans-serif}#m{position:absolute;inset:0 0 64px 0}
#i{position:absolute;left:0;right:0;bottom:0;height:64px;box-sizing:border-box;padding:8px 14px;background:#102a43;color:#fff;font-size:14px;line-height:1.35}
#i b{font-size:15px}</style></head><body><div id="m"></div><div id="i">Conectando…</div>
<script>
var base=location.pathname.replace(/\\/\$/,''),v=-1,mapa=L.map('m').setView([23.6,-102.5],4),mk=null,primera=true;
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(mapa);
var info=document.getElementById('i'),ult=null;
function hace(t){var s=Math.max(0,Math.round((Date.now()-new Date(t).getTime())/1000));return s<60?s+' s':Math.round(s/60)+' min';}
setInterval(function(){if(ult)info.innerHTML='<b>'+ult.estado+'</b> · actualizado hace '+hace(ult.t)+' · precisión ±'+ult.prec+' m';},1000);
function ciclo(){
 fetch(base+'/pos?v='+v,{cache:'no-store'}).then(function(r){return r.json();}).then(function(d){
  if(d.fin){info.innerHTML='<b>La ubicación dejó de compartirse.</b> El enlace venció o fue finalizado.';return;}
  if(!d.igual&&d.lat!==undefined){v=d.v;ult=d;var p=[d.lat,d.lon];
   if(!mk){mk=L.circleMarker(p,{radius:9,color:'#fff',weight:3,fillColor:'#1565c0',fillOpacity:1}).addTo(mapa);}else{mk.setLatLng(p);}
   if(primera){mapa.setView(p,16);primera=false;}else{mapa.panTo(p);}}
  ciclo();
 }).catch(function(){info.innerHTML='Sin conexión con el teléfono o el enlace venció. Reintentando…';setTimeout(ciclo,5000);});
}
ciclo();
</script></body></html>''';
}

// ============================================================================
//  Pantalla «Compartir mi ubicación en tiempo real»
// ============================================================================
class PantallaCompartir extends StatefulWidget {
  final Controlador c;
  const PantallaCompartir(this.c, {super.key});

  @override
  State<PantallaCompartir> createState() => _EstadoCompartir();
}

class _EstadoCompartir extends State<PantallaCompartir> {
  Duration? _dur = const Duration(hours: 1);
  bool _manual = false;

  CompartirUbicacion get _s => widget.c.compartir;

  @override
  void initState() {
    super.initState();
    unawaited(_s.revisarRed()); // el estado de la red se muestra desde que se abre la pantalla
  }

  String _cuenta(int s) {
    String d2(int v) => v.toString().padLeft(2, '0');
    return '${d2(s ~/ 3600)}:${d2((s % 3600) ~/ 60)}:${d2(s % 60)}';
  }

  String _mensaje(String url) => 'Sigue mi ubicación en tiempo real: $url\n(El enlace vence solo; si dejas de ver el punto, ya terminó.)';

  Future<void> _abrir(Uri u) async {
    var ok = false;
    try {
      ok = await launchUrl(u, mode: LaunchMode.externalApplication);
    } catch (_) {}
    if (!ok && mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No pude abrir esa aplicación.')));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _s,
      builder: (context, _) {
        final s = _s;
        final url = s.urlRemota ?? s.urlLocal;
        return Scaffold(
          appBar: AppBar(title: const Text('Compartir mi ubicación en tiempo real')),
          body: ListView(padding: const EdgeInsets.all(16), children: [
            // ---- estado de la red, siempre visible ----
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  color: s.conInternet ? const Color(0xFFE8F5E9) : const Color(0xFFFFEBEE),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: s.conInternet ? const Color(0xFF2E7D32) : const Color(0xFFC62828))),
              child: Row(children: [
                Icon(s.conInternet ? Icons.wifi : Icons.wifi_off, color: s.conInternet ? const Color(0xFF2E7D32) : const Color(0xFFC62828)),
                const SizedBox(width: 8),
                Expanded(
                  child: s.conInternet
                      ? const Text('Con conexión a internet')
                      : const Text(
                          'Sin conexión a internet — el enlace remoto no funcionará desde otra red.\nEl GPS local sigue activo y la transmisión remota se reanudará al recuperar conexión.',
                          style: TextStyle(fontWeight: FontWeight.w600)),
                ),
              ]),
            ),
            const SizedBox(height: 12),
            if (!s.activo) ...[
              const Text('Tu familiar o amigo abrirá un enlace en su navegador y verá un punto en el mapa. No necesita instalar nada.'),
              const SizedBox(height: 12),
              const Text('¿Cuánto tiempo?', style: TextStyle(fontWeight: FontWeight.bold)),
              Wrap(spacing: 8, children: [
                for (final e in <(String, Duration?)>[('30 minutos', const Duration(minutes: 30)), ('1 hora', const Duration(hours: 1)), ('3 horas', const Duration(hours: 3)), ('Corte manual', null)])
                  ChoiceChip(
                    label: Text(e.$1),
                    selected: e.$2 == null ? _manual : (!_manual && _dur == e.$2),
                    onSelected: (_) => setState(() {
                      _manual = e.$2 == null;
                      _dur = e.$2;
                    }),
                  ),
              ]),
              const SizedBox(height: 12),
              const Text('Consumo de datos', style: TextStyle(fontWeight: FontWeight.bold)),
              SegmentedButton<ModoCompartir>(
                segments: const [
                  ButtonSegment(value: ModoCompartir.ahorro, label: Text('Ahorro de datos')),
                  ButtonSegment(value: ModoCompartir.normal, label: Text('Normal')),
                ],
                selected: <ModoCompartir>{s.modo},
                onSelectionChanged: (v) => setState(() => s.modo = v.first),
              ),
              const Text('Solo se envían coordenadas ligeras (nunca imágenes del mapa). En «Ahorro» se envía menos seguido y casi nada si estás detenido.',
                  style: TextStyle(fontSize: 12)),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () => s.iniciar(_manual ? null : _dur),
                icon: const Icon(Icons.share_location),
                label: const Text('Compartir mi ubicación en tiempo real'),
              ),
            ] else ...[
              Row(children: [
                const Icon(Icons.timer_outlined),
                const SizedBox(width: 8),
                Expanded(
                    child: Text(s.segundosRestantes == null ? 'Activo hasta que lo finalices' : 'Activo · vence en ${_cuenta(s.segundosRestantes!)}',
                        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
              ]),
              const SizedBox(height: 10),
              const Text('Dirección web (nueva en cada activación):', style: TextStyle(fontWeight: FontWeight.bold)),
              if (s.urlRemota != null) SelectableText(s.urlRemota!, style: const TextStyle(color: Color(0xFF1565C0))),
              if (s.urlRemota == null && s.urlLocal != null) SelectableText('${s.urlLocal!}  (solo en la misma red Wi‑Fi)', style: const TextStyle(color: Color(0xFF1565C0))),
              if (s.estadoTunel.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(s.estadoTunel, style: const TextStyle(fontSize: 12))),
              const SizedBox(height: 8),
              if (url != null)
                Wrap(spacing: 8, runSpacing: 4, children: [
                  FilledButton.tonalIcon(
                    onPressed: () async {
                      await Clipboard.setData(ClipboardData(text: url));
                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enlace copiado')));
                    },
                    icon: const Icon(Icons.copy),
                    label: const Text('Copiar'),
                  ),
                  FilledButton.tonalIcon(
                    onPressed: () => _abrir(Uri.parse('https://wa.me/?text=${Uri.encodeComponent(_mensaje(url))}')),
                    icon: const Icon(Icons.chat),
                    label: const Text('WhatsApp'),
                  ),
                  FilledButton.tonalIcon(
                    onPressed: () => _abrir(Uri(scheme: 'sms', queryParameters: <String, String>{'body': _mensaje(url)})),
                    icon: const Icon(Icons.sms_outlined),
                    label: const Text('SMS'),
                  ),
                ]),
              const SizedBox(height: 12),
              const Text('Consumo de datos', style: TextStyle(fontWeight: FontWeight.bold)),
              SegmentedButton<ModoCompartir>(
                segments: const [
                  ButtonSegment(value: ModoCompartir.ahorro, label: Text('Ahorro de datos')),
                  ButtonSegment(value: ModoCompartir.normal, label: Text('Normal')),
                ],
                selected: <ModoCompartir>{s.modo},
                onSelectionChanged: (v) {
                  s.modo = v.first;
                  s.notifyListeners();
                },
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFFC62828)),
                onPressed: () => s.finalizar(),
                icon: const Icon(Icons.stop_circle_outlined),
                label: const Text('Finalizar / Vencer enlace ahora'),
              ),
            ],
          ]),
        );
      },
    );
  }
}
