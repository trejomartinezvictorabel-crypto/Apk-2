// ============================================================================
// AUDITORÍA COMPLETA Y AUTOREPARACIÓN (parte de main.dart: comparte lo privado)
// ----------------------------------------------------------------------------
//  • auditar(): revisa mapa, red vial/índice, GPS/navegación, voz, almacenamiento, integridad y los recursos
//    del usuario; cada punto sale con estado OK / Desactualizado / Advertencia / Error.
//  • autorreparar(): arregla en el teléfono lo que se puede (sin borrar lugares, rutas ni historial) y anota lo
//    que NO se pudo en «NO REPARADO EN EL TELÉFONO / REQUIERE COMPILACIÓN» para scripts/autoreparar_app.py.
// ============================================================================
part of 'main.dart';

enum EstadoAud { ok, desactualizado, advertencia, error }

String _etiquetaEstado(EstadoAud e) => switch (e) {
      EstadoAud.ok => 'OK',
      EstadoAud.desactualizado => 'Desactualizado',
      EstadoAud.advertencia => 'Advertencia',
      EstadoAud.error => 'Error',
    };

Color _colorEstado(EstadoAud e) => switch (e) {
      EstadoAud.ok => const Color(0xFF2E7D32),
      EstadoAud.desactualizado => const Color(0xFFEF6C00),
      EstadoAud.advertencia => const Color(0xFFF9A825),
      EstadoAud.error => const Color(0xFFC62828),
    };

class Hallazgo {
  final String modulo, titulo, detalle;
  final EstadoAud estado;
  /// Clave de lo que el teléfono no puede resolver solo (la lee scripts/autoreparar_app.py) y la acción a realizar.
  final String? pendClave, pendAccion;
  const Hallazgo(this.modulo, this.titulo, this.estado, this.detalle, {this.pendClave, this.pendAccion});
}

class PendienteCompilacion {
  final String modulo, motivo, accion, clave;
  const PendienteCompilacion(this.modulo, this.motivo, this.accion, this.clave);
}

class InfoReparacion {
  final List<String> reparado = <String>[];
  final List<String> actualizado = <String>[];
  final List<PendienteCompilacion> pendientes = <PendienteCompilacion>[];
  final List<String> registro = <String>[];
  List<Hallazgo> auditoriaInicial = <Hallazgo>[];
  List<Hallazgo> auditoriaFinal = <Hallazgo>[];
  List<Map<String, String>> paquetes = <Map<String, String>>[]; // desactualizados: nombre, actual, ultima
  DateTime fecha = DateTime.now();
}

/// Paquetes configurados en el flujo de trabajo (pubspec.yaml) — se comparan con pub.dev si hay internet.
const Map<String, String> kPaquetes = <String, String>{
  'flutter_map': '^6.2.1',
  'latlong2': '^0.9.1',
  'geolocator': '^12.0.0',
  'flutter_tts': '^4.0.2',
  'vosk_flutter': '^0.3.48',
  'sqflite': '^2.3.3+1',
  'path': '^1.9.0',
  'path_provider': '^2.1.4',
  'file_picker': '^8.1.2',
  'permission_handler': '^10.2.0',
  'wakelock_plus': '^1.2.8',
  'flutter_compass': '^0.8.1',
  'webview_flutter': '^4.10.0',
  'url_launcher': '^6.3.0',
  'dartssh2': '^2.9.0',
  'flutter_local_notifications': '^17.2.4',
};

// Últimos modelos «small» de Vosk que conoce esta versión de la app. Si el flujo de trabajo (autoreparar_app.py)
// recibe uno más nuevo y verificado, reescribe este bloque.
// AUTO:VOSK_MODELOS_BEGIN
const Map<String, String> kVoskUltimos = <String, String>{
  'es': 'vosk-model-small-es-0.42',
  'en': 'vosk-model-small-en-us-0.15',
  'pt': 'vosk-model-small-pt-0.3',
  'fr': 'vosk-model-small-fr-0.22',
  'de': 'vosk-model-small-de-0.15',
  'it': 'vosk-model-small-it-0.22',
};
// AUTO:VOSK_MODELOS_END

const int kDiasRevision = 90;

List<int> _versionDe(String t) {
  final m = RegExp(r'(\d+)(?:\.(\d+))?(?:\.(\d+))?').firstMatch(t);
  if (m == null) return <int>[0, 0, 0];
  return <int>[int.parse(m.group(1)!), int.tryParse(m.group(2) ?? '') ?? 0, int.tryParse(m.group(3) ?? '') ?? 0];
}

int _comparaVersion(List<int> a, List<int> b) {
  for (var i = 0; i < 3; i++) {
    if (a[i] != b[i]) return a[i].compareTo(b[i]);
  }
  return 0;
}

/// Nombres de las entradas de un .zip leyendo solo su directorio central; null si está dañado o incompleto.
Future<List<String>?> _entradasZip(File zip) async {
  RandomAccessFile? raf;
  try {
    raf = await zip.open();
    final largo = await raf.length();
    if (largo < 22) return null;
    final cola = math.min(largo, 65557);
    await raf.setPosition(largo - cola);
    final fin = Uint8List.fromList(await raf.read(cola));
    final bd = ByteData.sublistView(fin);
    var eocd = -1;
    for (var i = fin.length - 22; i >= 0; i--) {
      if (bd.getUint32(i, Endian.little) == 0x06054b50) {
        eocd = i;
        break;
      }
    }
    if (eocd < 0) return null;
    final n = bd.getUint16(eocd + 10, Endian.little);
    final tam = bd.getUint32(eocd + 12, Endian.little);
    final off = bd.getUint32(eocd + 16, Endian.little);
    if (off == 0xFFFFFFFF || off + tam > largo) return null;
    await raf.setPosition(off);
    final dir = Uint8List.fromList(await raf.read(tam));
    final cd = ByteData.sublistView(dir);
    final r = <String>[];
    var p = 0;
    for (var e = 0; e < n && p + 46 <= dir.length; e++) {
      if (cd.getUint32(p, Endian.little) != 0x02014b50) break;
      final nl = cd.getUint16(p + 28, Endian.little), el = cd.getUint16(p + 30, Endian.little), cl = cd.getUint16(p + 32, Endian.little);
      r.add(utf8.decode(dir.sublist(p + 46, p + 46 + nl), allowMalformed: true));
      p += 46 + nl + el + cl;
    }
    return r;
  } catch (_) {
    return null;
  } finally {
    try {
      await raf?.close();
    } catch (_) {}
  }
}

/// ¿El .geojson termina bien (no quedó cortado a la mitad)?
Future<bool> _geojsonCompleto(File f) async {
  RandomAccessFile? raf;
  try {
    raf = await f.open();
    final largo = await raf.length();
    if (largo < 2) return false;
    final n = math.min(largo, 4096);
    await raf.setPosition(largo - n);
    final t = utf8.decode(await raf.read(n), allowMalformed: true).trimRight();
    return t.endsWith('}') || t.endsWith(']');
  } catch (_) {
    return false;
  } finally {
    try {
      await raf?.close();
    } catch (_) {}
  }
}

String _fechaHora(DateTime d) {
  String d2(int v) => v.toString().padLeft(2, '0');
  return '${d.year}-${d2(d.month)}-${d2(d.day)} ${d2(d.hour)}:${d2(d.minute)}';
}

String _tamano(int bytes) {
  if (bytes < 1048576) return '${(bytes / 1024).toStringAsFixed(0)} KB';
  if (bytes < 1073741824) return '${(bytes / 1048576).toStringAsFixed(1)} MB';
  return '${(bytes / 1073741824).toStringAsFixed(2)} GB';
}

extension AuditoriaControlador on Controlador {
  Future<bool> hayInternet() async {
    try {
      final r = await InternetAddress.lookup('pub.dev').timeout(const Duration(seconds: 4));
      return r.isNotEmpty && r.first.rawAddress.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  Future<Map<String, int>> _memoria() async {
    final r = <String, int>{};
    try {
      for (final l in await File('/proc/meminfo').readAsLines()) {
        final m = RegExp(r'^(MemTotal|MemAvailable):\s+(\d+)').firstMatch(l);
        if (m != null) r[m.group(1)!] = int.parse(m.group(2)!) * 1024;
      }
    } catch (_) {}
    return r;
  }

  Future<int?> _espacioLibre(String ruta) async {
    try {
      final r = await Process.run('df', ['-k', ruta]).timeout(const Duration(seconds: 4));
      final lineas = '${r.stdout}'.trim().split('\n');
      if (lineas.length < 2) return null;
      final c = lineas.last.trim().split(RegExp(r'\s+'));
      return int.tryParse(c[3]) == null ? null : int.parse(c[3]) * 1024;
    } catch (_) {
      return null;
    }
  }

  /// Consulta pub.dev (solo con internet) y devuelve los paquetes con versión más nueva.
  Future<List<Map<String, String>>> paquetesDesactualizados() async {
    final r = <Map<String, String>>[];
    await Future.wait(kPaquetes.entries.map((e) async {
      final cli = HttpClient()..connectionTimeout = const Duration(seconds: 6);
      try {
        final req = await cli.getUrl(Uri.parse('https://pub.dev/api/packages/${e.key}'));
        final resp = await req.close().timeout(const Duration(seconds: 8));
        if (resp.statusCode != 200) return;
        final txt = await resp.transform(utf8.decoder).join();
        final ult = (jsonDecode(txt) as Map)['latest']?['version']?.toString();
        if (ult == null) return;
        final actual = e.value.replaceAll('^', '');
        if (_comparaVersion(_versionDe(ult), _versionDe(actual)) > 0) {
          r.add(<String, String>{
            'nombre': e.key,
            'actual': actual,
            'ultima': ult,
            'mayor': _versionDe(ult)[0] > _versionDe(actual)[0] ? 'si' : 'no',
          });
        }
      } catch (_) {} finally {
        cli.close(force: true);
      }
    }));
    r.sort((a, b) => a['nombre']!.compareTo(b['nombre']!));
    return r;
  }

  /// Cuenta elementos del índice por categoría (lectura en flujo).
  Future<Map<String, int>> _contarIndice() async {
    final r = <String, int>{'calles': 0, 'colonias': 0, 'localidades': 0, 'comercios y servicios': 0, 'otros lugares': 0};
    for (final ruta in _indicesCalles.values) {
      try {
        final lineas = File(ruta).openRead().transform(utf8.decoder).transform(const LineSplitter());
        await for (final l in lineas) {
          final p = l.split('\t');
          if (p.length < 6) continue;
          final c = p[4].split(' ').first;
          switch (c) {
            case 'calle': r['calles'] = r['calles']! + 1;
            case 'colonia': r['colonias'] = r['colonias']! + 1;
            case 'localidad': r['localidades'] = r['localidades']! + 1;
            case 'lugar': r['otros lugares'] = r['otros lugares']! + 1;
            default: r['comercios y servicios'] = r['comercios y servicios']! + 1;
          }
        }
      } catch (_) {}
    }
    return r;
  }

  Future<List<Hallazgo>> auditar({bool internet = true}) async {
    final h = <Hallazgo>[];
    void add(String m, String t, EstadoAud e, String d, {String? clave, String? accion}) =>
        h.add(Hallazgo(m, t, e, d, pendClave: clave, pendAccion: accion));
    final ahora = DateTime.now();
    final online = internet && await hayInternet();

    // ---------------- MAPA ----------------
    try {
      add('Mapa', 'Vista del mapa', vistaMapaLista ? EstadoAud.ok : EstadoAud.advertencia,
          vistaMapaLista ? 'La superficie del mapa está lista y dibujando.' : 'La vista del mapa aún no avisó que está lista.');
      final rean = ultimaReanudacion;
      add('Mapa', 'Reanudación (segundo plano / pantalla apagada)', rean == null || vistaMapaLista ? EstadoAud.ok : EstadoAud.error,
          rean == null ? 'Sin pausas desde que se abrió la app.' : 'Última reanudación: ${_fechaHora(rean)}${vistaMapaLista ? '' : ' · el mapa no se reenganchó'}');
      if (mapas.isEmpty) {
        add('Mapa', 'Archivo .mbtiles activo', EstadoAud.advertencia, 'No hay mapa activo. Elígelo con el botón de capas.');
      } else {
        final okZoom = zoomMinTiles >= 0 && zoomMaxTiles <= 20 && zoomMinTiles <= zoomMaxTiles;
        add('Mapa', 'Zoom del motor', okZoom ? EstadoAud.ok : EstadoAud.error,
            'Archivo: $mapaActivo · zoom del archivo $zoomMinTiles–$zoomMaxTiles (permitido 0–20) · zoom actual ${zoomVista.toStringAsFixed(1)}');
        final p = proveedorTiles;
        if (p is ProveedorMbTiles) {
          for (var i = 0; i < p.bases.length; i++) {
            try {
              final t = (await p.bases[i].rawQuery("SELECT name FROM sqlite_master WHERE type IN ('table','view')")).map((e) => '${e['name']}').toSet();
              final hayTiles = t.contains('tiles');
              var hay = false;
              if (hayTiles) hay = (await p.bases[i].rawQuery('SELECT 1 FROM tiles LIMIT 1')).isNotEmpty;
              final ok = hayTiles && hay;
              add('Mapa', 'Integridad del .mbtiles', ok ? EstadoAud.ok : EstadoAud.error,
                  ok ? 'Tablas ${t.join(', ')} · con teselas.' : 'Falta la tabla de teselas o está vacía (tablas: ${t.join(', ')}).',
                  clave: ok ? null : 'archivo_danado', accion: ok ? null : 'Vuelve a exportar $mapaActivo en HOT Export; el archivo está incompleto.');
            } catch (e) {
              add('Mapa', 'Integridad del .mbtiles', EstadoAud.error, 'No se pudo leer: $e',
                  clave: 'archivo_danado', accion: 'Vuelve a exportar $mapaActivo en HOT Export.');
            }
          }
        }
      }
    } catch (e) {
      add('Mapa', 'Revisión del mapa', EstadoAud.error, '$e');
    }

    // ---------------- RED VIAL, LUGARES E ÍNDICE ----------------
    try {
      final red = motor.red;
      if (redActiva.isEmpty) {
        add('Red vial', 'Archivo .geojson activo', EstadoAud.advertencia, 'No hay red vial activa. Elígela con el botón de capas.');
      } else {
        add('Red vial', 'Archivo .geojson activo', redCargada ? EstadoAud.ok : EstadoAud.advertencia,
            '$redActiva · ${redCargada ? 'cargado' : 'sin cargar todavía'}');
      }
      final n = redesDisponiblesLista.where((f) => Controlador.esClipping(f.path)).length;
      add('Red vial', 'Exclusión de clipping_boundary.geojson', n == 0 ? EstadoAud.ok : EstadoAud.error,
          n == 0 ? 'Se ignora y no sale en las listas ni en la cuenta (${redesDisponiblesLista.length} archivo(s) válidos).' : 'Aparece $n vez/veces en la lista: hay que revisar el filtro.');
      final v = _ventanaRed;
      if (v != null) {
        final alto = (v.n - v.s) * 111.0;
        add('Red vial', 'Radio dinámico de 45 km', alto <= 110 ? EstadoAud.ok : EstadoAud.advertencia,
            'Zona en memoria ≈ ${alto.toStringAsFixed(0)} km de alto · ${red?.nodos ?? 0} nodos · ${red?.nombres.length ?? 0} calles con nombre.');
      } else if (redActiva.isNotEmpty) {
        add('Red vial', 'Radio dinámico de 45 km', EstadoAud.advertencia, 'Todavía no hay zona cargada (¿sin GPS ni archivo cargado?).');
      }
      if (_indicesCalles.isEmpty) {
        add('Índice', 'Índice completo del .geojson', redActiva.isEmpty ? EstadoAud.advertencia : (_indexando ? EstadoAud.advertencia : EstadoAud.error),
            _indexando ? 'Se está creando (puede tardar varios minutos).' : 'No hay índice. La autoreparación puede reconstruirlo.');
      } else {
        final c = await _contarIndice().timeout(const Duration(seconds: 40), onTimeout: () => <String, int>{});
        final total = c.values.fold<int>(0, (a, b) => a + b);
        add('Índice', 'Elementos indexados', total > 0 ? EstadoAud.ok : EstadoAud.error,
            c.isEmpty ? 'No se pudo contar a tiempo.' : c.entries.map((e) => '${e.value} ${e.key}').join(' · '));
        final t0 = DateTime.now();
        final prueba = await buscarCercanos('gasolinera', limite: 5);
        final ms = DateTime.now().difference(t0).inMilliseconds;
        add('Índice', 'Prueba rápida de consulta', EstadoAud.ok,
            'Consulta «gasolinera»: ${prueba.length} resultado(s) en $ms ms${prueba.isEmpty ? ' (puede que el archivo no tenga gasolineras)' : ' · más cercana: ${prueba.first.titulo}'}');
      }
    } catch (e) {
      add('Red vial', 'Revisión de la red vial', EstadoAud.error, '$e');
    }

    // ---------------- GPS, NAVEGACIÓN Y CÁMARA ----------------
    try {
      final loc = await Permission.locationWhenInUse.isGranted;
      add('GPS', 'Permiso de ubicación', loc ? EstadoAud.ok : EstadoAud.error, loc ? 'Concedido.' : 'Falta el permiso de ubicación.');
      final siempre = await Permission.locationAlways.isGranted;
      add('GPS', 'Ubicación en segundo plano', EstadoAud.ok,
          siempre ? 'Concedida («todo el tiempo»).' : 'No hace falta: con una ruta o grabación activa, el servicio en primer plano mantiene el GPS con la pantalla apagada.');
      final u = ubic;
      add('GPS', 'Señal GPS', u == null ? EstadoAud.advertencia : (u.accuracy > 50 ? EstadoAud.advertencia : EstadoAud.ok),
          u == null ? 'Sin posición todavía.' : '${u.latitude.toStringAsFixed(5)}, ${u.longitude.toStringAsFixed(5)} (±${u.accuracy.round()} m)');
      final activa = fase == Fase.navegando;
      add('Navegación', 'Ruta activa', EstadoAud.ok, activa ? 'Sí · quedan ${Fmt.dist(restanteM)}' : 'No hay ruta activa.');
      final debe = fase == Fase.navegando || grabando || compartiendo;
      add('Navegación', 'Servicio en segundo plano', debe == _gpsConNotificacion ? EstadoAud.ok : EstadoAud.error,
          debe ? (_gpsConNotificacion ? 'Activo con notificación fija.' : 'Debería estar activo y no lo está.') : 'No se necesita ahora.');
      add('Cámara', 'Cámara dinámica', EstadoAud.ok,
          'Seguimiento, inclinación y giro por rumbo ${brujulaDisponible ? '(brújula disponible)' : '(sin brújula: usa el rumbo del GPS)'}.');
    } catch (e) {
      add('GPS', 'Revisión del GPS', EstadoAud.error, '$e');
    }

    // ---------------- VOZ E IDIOMA ----------------
    try {
      final idioma = gIdioma.value;
      add('Voz', 'Idioma de la interfaz', EstadoAud.ok, idioma);
      final mic = await Permission.microphone.isGranted;
      add('Voz', 'Micrófono', mic ? EstadoAud.ok : EstadoAud.error, mic ? 'Permiso concedido.' : 'Falta el permiso de micrófono.');
      final voces = await vocesDisponibles();
      add('Voz', 'Síntesis de voz (TTS)', voces.isNotEmpty ? EstadoAud.ok : EstadoAud.advertencia,
          voces.isNotEmpty ? '${voces.length} voz/voces disponibles' : 'No se encontraron voces instaladas (instálalas en los ajustes de Android).');
      final externo = stt.rutaExterna;
      final nombreModelo = externo == null ? kVoskUltimos['es']! : ruta_p.basename(externo);
      add('Voz', 'Modelo Vosk seleccionado', stt.voskListo ? EstadoAud.ok : EstadoAud.error,
          '$nombreModelo${externo == null ? ' (incluido en la app)' : ''} · ${stt.estadoModelo}',
          clave: stt.voskListo ? null : 'vosk_modelo', accion: stt.voskListo ? null : 'Verifica que el modelo $nombreModelo exista en assets/models o vuelve a descargarlo.');
      if (externo != null) {
        final completo = Directory(ruta_p.join(externo, 'am')).existsSync() &&
            Directory(ruta_p.join(externo, 'conf')).existsSync() &&
            (Directory(ruta_p.join(externo, 'graph')).existsSync() || Directory(ruta_p.join(externo, 'ivector')).existsSync());
        add('Voz', 'Integridad del modelo', completo ? EstadoAud.ok : EstadoAud.error,
            completo ? 'Carpetas am, conf y graph presentes.' : 'Faltan carpetas del modelo (am/conf/graph): descarga incompleta.');
      }
      final ult = kVoskUltimos[idioma] ?? kVoskUltimos['es']!;
      final prefijo = ult.replaceAll(RegExp(r'-\d+(\.\d+)*$'), '');
      final vigente = nombreModelo.startsWith(prefijo) ? _comparaVersion(_versionDe(nombreModelo.substring(prefijo.length)), _versionDe(ult.substring(prefijo.length))) >= 0 : true;
      add('Voz', '¿Hay modelo más moderno?', vigente ? EstadoAud.ok : EstadoAud.desactualizado,
          vigente ? 'Tienes la versión más reciente que conoce esta app ($ult).' : 'Hay $ult disponible (tienes $nombreModelo).',
          clave: vigente ? null : 'vosk_modelo', accion: vigente ? null : 'Usar $ult (verificar que exista en alphacephei.com/vosk/models).');
    } catch (e) {
      add('Voz', 'Revisión de la voz', EstadoAud.error, '$e');
    }

    // ---------------- ALMACENAMIENTO Y MEMORIA ----------------
    try {
      final acceso = await _tienePermisoDescargas();
      add('Almacenamiento', 'Acceso a Descargas', acceso ? EstadoAud.ok : EstadoAud.advertencia,
          acceso ? 'Permiso «Acceso a todos los archivos» concedido.' : 'Falta el permiso de acceso a todos los archivos.');
      final sd = await _carpetasSd();
      add('Almacenamiento', 'Tarjeta microSD', EstadoAud.ok, sd.isEmpty ? 'No detecté tarjeta (normal si tu teléfono no tiene).' : 'Detectada: ${sd.first}');
      var corruptos = 0, pendientes = 0;
      final detalle = <String>[];
      if (acceso) {
        for (final esSd in <bool>[false, true]) {
          for (final z in await _archivosExternos(esSd, (p) => p.toLowerCase().endsWith('.zip'))) {
            final ent = await _entradasZip(z);
            if (ent == null) {
              corruptos++;
              detalle.add('${ruta_p.basename(z.path)}: dañado o incompleto');
              continue;
            }
            final utiles = ent.where((n) {
              final b = ruta_p.basename(n).toLowerCase();
              return (b.endsWith('.mbtiles') || b.endsWith('.geojson')) && !Controlador.esClipping(b);
            });
            final falta = utiles.any((n) => !File(ruta_p.join(z.parent.path, ruta_p.basename(n))).existsSync());
            if (falta) {
              pendientes++;
              detalle.add('${ruta_p.basename(z.path)}: pendiente de descomprimir');
            }
          }
        }
      }
      add('Almacenamiento', 'Archivos .zip', corruptos > 0 ? EstadoAud.error : (pendientes > 0 ? EstadoAud.advertencia : EstadoAud.ok),
          corruptos + pendientes == 0 ? 'Sin .zip pendientes ni dañados.' : detalle.join(' · '),
          clave: corruptos > 0 ? 'archivo_danado' : null, accion: corruptos > 0 ? 'Vuelve a descargar los .zip dañados (no se pueden recuperar en el teléfono).' : null);
      final mem = await _memoria();
      if (mem.isNotEmpty) {
        final tot = mem['MemTotal'] ?? 0, disp = mem['MemAvailable'] ?? 0;
        final pct = tot == 0 ? 100 : (disp * 100 / tot);
        add('Memoria', 'RAM', pct < 10 ? EstadoAud.advertencia : EstadoAud.ok, '${_tamano(disp)} libres de ${_tamano(tot)} (${pct.toStringAsFixed(0)} %)');
      }
      final libre = await _espacioLibre((await getApplicationSupportDirectory()).path);
      if (libre != null) {
        add('Almacenamiento', 'Espacio libre', libre < 300 * 1048576 ? EstadoAud.advertencia : EstadoAud.ok, '${_tamano(libre)} libres');
      }
    } catch (e) {
      add('Almacenamiento', 'Revisión del almacenamiento', EstadoAud.error, '$e');
    }

    // ---------------- INTEGRIDAD INTERNA, VERSIONES Y REGISTROS ----------------
    try {
      var bdOk = false;
      try {
        final r = await datos.db.rawQuery('PRAGMA quick_check');
        bdOk = '${r.first.values.first}' == 'ok';
      } catch (_) {}
      add('Integridad', 'Base de datos local', bdOk ? EstadoAud.ok : EstadoAud.error,
          bdOk ? 'quick_check OK · ${pois.length} puntos, ${rutasFrec.length} rutas frecuentes, ${historial.length} del historial.' : 'La base de datos no pasó la verificación.',
          clave: bdOk ? null : 'base_datos', accion: bdOk ? null : 'Base de datos dañada: copia tus datos y reinstala; el APK nuevo la recrea.');
      var prefsOk = false;
      try {
        final d = await getApplicationDocumentsDirectory();
        final f = File(ruta_p.join(d.path, 'ajustes_descarga.json'));
        prefsOk = !f.existsSync() || jsonDecode(await f.readAsString()) is Map;
      } catch (_) {}
      add('Integridad', 'Preferencias', prefsOk ? EstadoAud.ok : EstadoAud.error, prefsOk ? 'Archivo de preferencias válido.' : 'El archivo de preferencias está dañado.');
      final carpetasOk = <String>[];
      for (final n in <String>['mapas', 'red', 'indices']) {
        try {
          await _carpeta(n);
          carpetasOk.add(n);
        } catch (_) {}
      }
      add('Integridad', 'Carpetas internas', carpetasOk.length == 3 ? EstadoAud.ok : EstadoAud.error, carpetasOk.join(', '));
      if (online) {
        final viejos = await paquetesDesactualizados();
        for (final p in viejos) {
          final mayor = p['mayor'] == 'si';
          add('Versiones', p['nombre']!, EstadoAud.desactualizado,
              'Configurado ${p['actual']} · disponible ${p['ultima']}${mayor ? ' (versión mayor: puede requerir cambios de código)' : ' (compatible)'}',
              clave: mayor ? 'paquete_mayor' : 'paquetes',
              accion: mayor ? 'Revisar la migración de ${p['nombre']} a ${p['ultima']} antes de subirla.' : 'Subir ${p['nombre']} a ^${p['ultima']} en pubspec.yaml.');
        }
        if (viejos.isEmpty) add('Versiones', 'Dependencias', EstadoAud.ok, 'Todas las dependencias están en su última versión (según pub.dev).');
      } else {
        add('Versiones', 'Dependencias', EstadoAud.advertencia,
            'Sin internet: no se pudo comparar con pub.dev. Configuradas: ${kPaquetes.entries.map((e) => '${e.key} ${e.value}').join(', ')}');
      }
      add('Integridad', 'Android del dispositivo', EstadoAud.ok, Platform.operatingSystemVersion);
      final errores = Registro._lineas.where((l) => l.contains('ERROR') || l.contains('⚠')).toList();
      add('Registros', 'Últimos errores capturados', errores.isEmpty ? EstadoAud.ok : EstadoAud.advertencia,
          errores.isEmpty ? 'Ninguno.' : errores.reversed.take(8).toList().reversed.join('\n'));
    } catch (e) {
      add('Integridad', 'Revisión interna', EstadoAud.error, '$e');
    }

    // ---------------- RECURSOS ELEGIDOS POR EL USUARIO ----------------
    try {
      String edad(File f) {
        final d = ahora.difference(f.statSync().modified).inDays;
        return '${_fechaHora(f.statSync().modified)} (hace $d días)';
      }
      EstadoAud porEdad(File f, bool completo) {
        if (!completo) return EstadoAud.error;
        return ahora.difference(f.statSync().modified).inDays > kDiasRevision ? EstadoAud.desactualizado : EstadoAud.ok;
      }
      // voz
      final ext = stt.rutaExterna;
      if (ext != null) {
        final dir = Directory(ext);
        final comp = Directory(ruta_p.join(ext, 'am')).existsSync();
        add('Recursos', 'Voz · ${ruta_p.basename(ext)}', comp ? EstadoAud.ok : EstadoAud.error, '$ext · ${comp ? 'completo' : 'dañado o incompleto'} · ${dir.existsSync() ? _fechaHora(dir.statSync().modified) : ''}');
      } else {
        add('Recursos', 'Voz · español incluido en la app', EstadoAud.ok, 'Viene dentro del APK; se actualiza al compilar un APK nuevo.');
      }
      // mapa
      for (final m in mapasDisponiblesLista.where((m) => m.nombre == mapaActivo)) {
        final f = File(m.ruta);
        final ok = mapas.isNotEmpty;
        final st = porEdad(f, ok);
        add('Recursos', 'Mapa · ${m.nombre}', st,
            '${m.ruta} · ${_tamano(f.lengthSync())} · ${ok ? 'completo' : 'dañado'} · ${edad(f)}${st == EstadoAud.desactualizado ? ' · tiene más de 3 meses: conviene exportar uno nuevo' : ''}');
      }
      // red vial y negocios
      for (final f in redesDisponiblesLista.where((f) => ruta_p.basename(f.path) == redActiva)) {
        final ok = await _geojsonCompleto(f);
        final st = porEdad(f, ok);
        add('Recursos', 'Red vial y negocios · ${ruta_p.basename(f.path)}', st,
            '${f.path} · ${_tamano(f.lengthSync())} · ${ok ? 'completo' : 'cortado o dañado'} · ${edad(f)}${st == EstadoAud.desactualizado ? ' · tiene más de 3 meses: conviene exportar uno nuevo' : ''}',
            clave: ok ? null : 'archivo_danado', accion: ok ? null : 'Vuelve a exportar ${ruta_p.basename(f.path)}; no se puede reparar en el teléfono.');
      }
      add('Recursos', 'Rutas guardadas', EstadoAud.ok, '${rutasFrec.length} rutas frecuentes y ${pois.length} puntos (se conservan siempre).');
    } catch (e) {
      add('Recursos', 'Recursos del usuario', EstadoAud.error, '$e');
    }
    return h;
  }

  // ======================================================================
  //  AUTOREPARACIÓN
  // ======================================================================
  Future<InfoReparacion> autorreparar({
    required void Function(double, String) progreso,
    required Future<bool> Function(String) confirmar,
  }) async {
    final info = InfoReparacion();
    void log(String t) {
      info.registro.add('[${_fechaHora(DateTime.now())}] $t');
      Registro.anotar('Autoreparación: $t');
      progreso(-1, t);
    }
    Future<void> paso(double p, String titulo, Future<void> Function() f) async {
      progreso(p, titulo);
      log('▶ $titulo');
      try {
        await f();
      } catch (e) {
        log('✖ Falló «$titulo»: $e');
        info.pendientes.add(PendienteCompilacion('Autoreparación', 'Falló «$titulo»: $e', 'Revisar el registro y reintentar; si persiste, compilar un APK nuevo.', 'paso_fallido'));
      }
    }

    progreso(0.02, 'Auditoría inicial…');
    log('▶ Auditoría inicial');
    info.auditoriaInicial = await auditar();
    info.paquetes = await paquetesDesactualizados();

    await paso(0.12, '1/6 Reenganchando mapa y cámara', () async {
      ordenReenganche++;
      notifyListeners();
      await Future<void>.delayed(const Duration(milliseconds: 1500));
      info.reparado.add('Superficie del mapa y cámara reenganchadas.');
      log('✔ Mapa reenganchado');
    });

    await paso(0.25, '2/6 Limpiando cachés y archivos temporales (sin tocar tus datos)', () async {
      _ImagenMbTile.vaciarCache();
      _ImagenMbTile.reiniciarCola();
      var borrados = 0, bytes = 0;
      Future<void> limpiar(Directory d, {bool soloViejos = false, String? ext}) async {
        try {
          if (!await d.exists()) return;
          await for (final e in d.list(followLinks: false)) {
            if (e is! File) continue;
            final n = e.path.toLowerCase();
            if (ext != null && !n.endsWith(ext)) continue;
            if (soloViejos && DateTime.now().difference(e.statSync().modified).inHours < 24) continue;
            try {
              bytes += e.lengthSync();
              await e.delete();
              borrados++;
            } catch (_) {}
          }
        } catch (_) {}
      }
      await limpiar(await getTemporaryDirectory());
      for (final sub in <String>['mapas', 'red', 'indices']) {
        final d = await _carpeta(sub);
        await limpiar(d, ext: '.tmp');
        await limpiar(d, ext: '.part');
      }
      for (final sd in <bool>[false, true]) {
        try {
          for (final ruta in sd ? await _carpetasSd() : await _carpetasDescargas()) {
            await limpiar(Directory(ruta), soloViejos: true, ext: '.part'); // descargas a medias de hace más de un día
          }
        } catch (_) {}
      }
      if (calculando && fase != Fase.navegando) calculando = false; // estado colgado
      notifyListeners();
      info.reparado.add('Cachés y temporales limpiados ($borrados archivo(s), ${_tamano(bytes)}). Lugares, rutas e historial intactos.');
      log('✔ Limpieza: $borrados archivo(s)');
    });

    await paso(0.45, '3/6 Reconstruyendo el índice del .geojson y la zona de 45 km', () async {
      if (redActiva.isEmpty) {
        log('No hay .geojson activo: no hay nada que indexar.');
        return;
      }
      final dir = await _carpeta('indices');
      var n = 0;
      for (final f in dir.listSync().whereType<File>()) {
        if (f.path.endsWith('.idx') || f.path.endsWith('.idx.tmp')) {
          try {
            f.deleteSync();
            n++;
          } catch (_) {}
        }
      }
      _indicesCalles.clear();
      final u = ubic;
      await _cargarRedGuardada(centro: u == null ? null : LatLng(u.latitude, u.longitude));
      var seg = 0;
      while (_indexando && seg < 600) {
        await Future<void>.delayed(const Duration(seconds: 1));
        seg++;
        if (seg % 5 == 0) progreso(-1, 'Indexando… ${seg}s');
      }
      for (var i = 0; i < 20 && _indicesCalles.isEmpty && !_indexando; i++) {
        await Future<void>.delayed(const Duration(milliseconds: 500));
      }
      if (_indicesCalles.isEmpty) {
        info.pendientes.add(const PendienteCompilacion('Red vial / índice', 'No se pudo reconstruir el índice del .geojson activo.',
            'Verificar que el .geojson sea válido (exportación HOT en formato GeoJSON) y reexportarlo.', 'indice'));
        log('✖ El índice no se pudo reconstruir');
      } else {
        info.reparado.add('Índice reconstruido desde cero ($n anterior(es) eliminados) y zona de 45 km recargada.');
        log('✔ Índice listo');
      }
    });

    await paso(0.62, '4/6 Reescaneando Descargas y microSD, y descomprimiendo .zip', () async {
      if (!await _tienePermisoDescargas()) {
        log('Sin permiso de archivos: no se puede reescanear.');
        info.pendientes.add(const PendienteCompilacion('Almacenamiento', 'Falta el permiso «Acceso a todos los archivos».',
            'Concede el permiso en los ajustes de Android y repite la autoreparación.', 'permiso_archivos'));
        return;
      }
      var descomprimidos = 0;
      for (final sd in <bool>[false, true]) {
        for (final z in await _archivosExternos(sd, (p) => p.toLowerCase().endsWith('.zip'))) {
          final ent = await _entradasZip(z);
          if (ent == null) {
            info.pendientes.add(PendienteCompilacion('Almacenamiento', '${ruta_p.basename(z.path)} está dañado o incompleto (no recuperable en el teléfono).',
                'Volver a descargar ${ruta_p.basename(z.path)} desde HOT Export.', 'archivo_danado'));
            log('✖ ${ruta_p.basename(z.path)}: dañado');
            continue;
          }
          final falta = ent.any((n) {
            final b = ruta_p.basename(n).toLowerCase();
            return (b.endsWith('.mbtiles') || b.endsWith('.geojson')) && !Controlador.esClipping(b) && !File(ruta_p.join(z.parent.path, ruta_p.basename(n))).existsSync();
          });
          if (!falta) continue;
          try {
            final (creados, _) = await DescargaWeb.descomprimir(z, z.parent, estado: (t) => progreso(-1, t), cancelado: () => false);
            descomprimidos += creados.length;
            log('✔ ${ruta_p.basename(z.path)}: ${creados.length} archivo(s) extraídos');
          } catch (e) {
            info.pendientes.add(PendienteCompilacion('Almacenamiento', 'No se pudo descomprimir ${ruta_p.basename(z.path)}: $e', 'Volver a descargarlo.', 'archivo_danado'));
          }
        }
      }
      await _abrirMapas();
      await redesDisponibles();
      var danados = 0;
      for (final f in redesDisponiblesLista) {
        if (!await _geojsonCompleto(f)) {
          danados++;
          info.pendientes.add(PendienteCompilacion('Red vial', '${ruta_p.basename(f.path)} parece cortado o incompleto.',
              'Volver a exportarlo en HOT Export (no se puede reparar en el teléfono).', 'archivo_danado'));
        }
      }
      info.reparado.add('Descargas y microSD reescaneadas: $descomprimidos archivo(s) descomprimidos; .mbtiles y .geojson revalidados${danados > 0 ? ' ($danados dañado(s))' : ''}.');
      log('✔ Reescaneo terminado');
    });

    await paso(0.80, '5/6 Revisando el modelo de voz Vosk', () async {
      final idioma = gIdioma.value;
      final ult = kVoskUltimos[idioma] ?? kVoskUltimos['es']!;
      final ext = stt.rutaExterna;
      final actual = ext == null ? null : ruta_p.basename(ext);
      final incompleto = ext != null && !Directory(ruta_p.join(ext, 'am')).existsSync();
      final prefijo = ult.replaceAll(RegExp(r'-\d+(\.\d+)*$'), '');
      final viejo = actual != null && actual.startsWith(prefijo) && _comparaVersion(_versionDe(actual.substring(prefijo.length)), _versionDe(ult.substring(prefijo.length))) < 0;
      if (ext == null && !stt.voskListo) {
        info.pendientes.add(PendienteCompilacion('Voz', 'El modelo incluido en el APK no se pudo cargar.',
            'El flujo de trabajo debe descargar ${kVoskUltimos['es']} a assets/models/ (paso 1) y compilar.', 'vosk_modelo'));
      }
      if (incompleto || viejo) {
        if (!await hayInternet()) {
          log('Sin internet: no se puede actualizar el modelo ahora.');
          info.pendientes.add(PendienteCompilacion('Voz', '${incompleto ? 'Modelo incompleto' : 'Modelo desactualizado'} ($actual) y sin conexión para actualizarlo.',
              'Usar $ult: el flujo de trabajo / autoreparar_app.py lo verifica; o repite con internet.', 'vosk_modelo'));
        } else if (await confirmar('Descargar $ult (≈40 MB) desde alphacephei.com para ${incompleto ? 'reparar' : 'actualizar'} tu modelo de voz? Usará datos móviles si no estás en Wi‑Fi.')) {
          final dest = (await _carpetaDescarga(false, 'modelos')).dir;
          final zip = await DescargaWeb.bajar(Uri.parse('https://alphacephei.com/vosk/models/$ult.zip'), dest,
              progreso: (b, t) => progreso(-1, 'Descargando modelo… ${_tamano(b)}${t == null ? '' : ' de ${_tamano(t)}'}'), cancelado: () => false);
          await DescargaWeb.descomprimir(zip, dest, estado: (t) => progreso(-1, t), cancelado: () => false, todo: true);
          final nuevo = Directory(ruta_p.join(dest.path, ult));
          if (Directory(ruta_p.join(nuevo.path, 'am')).existsSync()) {
            await establecerModeloVoz(nuevo.path);
            info.actualizado.add('Modelo de voz actualizado a $ult.');
            log('✔ Modelo $ult instalado y activado');
          } else {
            throw Exception('El .zip descargado no contiene el modelo esperado.');
          }
        } else {
          log('Actualización del modelo omitida por el usuario.');
        }
      } else if (ext == null && ult != kVoskUltimos['es']) {
        log('Español incluido en la app: sin cambios.');
      } else {
        log('✔ Modelo de voz vigente');
      }
    });

    await paso(0.90, '6/6 Anotando lo que el teléfono no puede resolver', () async {
      for (final p in info.paquetes) {
        final mayor = p['mayor'] == 'si';
        info.pendientes.add(PendienteCompilacion('Versiones', '${p['nombre']} ${p['actual']} → ${p['ultima']}${mayor ? ' (versión mayor)' : ''}',
            mayor ? 'Revisar migración antes de subir ${p['nombre']} a ${p['ultima']}.' : 'Subir ${p['nombre']} a ^${p['ultima']} en pubspec.yaml.', mayor ? 'paquete_mayor' : 'paquetes'));
      }
      info.pendientes.add(const PendienteCompilacion('Android 16', 'Compatibilidad del APK con Android 16 (SDK 36, 16 KB de página, notificaciones y desugaring).',
          'autoreparar_app.py asegura compileSdk/targetSdk 36, permisos del manifiesto y desugaring para las notificaciones locales.', 'android16'));
      for (final h in info.auditoriaInicial) {
        if (h.pendClave != null && h.estado != EstadoAud.ok &&
            !info.pendientes.any((p) => p.clave == h.pendClave && p.motivo.contains(h.titulo))) {
          info.pendientes.add(PendienteCompilacion(h.modulo, '${h.titulo}: ${h.detalle}', h.pendAccion ?? 'Revisar.', h.pendClave!));
        }
      }
    });

    progreso(0.95, 'Auditoría final…');
    log('▶ Auditoría final');
    info.auditoriaFinal = await auditar(internet: false);
    // Lo que ya quedó arreglado sale de la lista de pendientes
    info.pendientes.removeWhere((p) =>
        (p.clave == 'indice' && _indicesCalles.isNotEmpty) ||
        (p.clave == 'vosk_modelo' && stt.voskListo && info.actualizado.isNotEmpty));
    info.fecha = DateTime.now();
    progreso(1.0, 'Autoreparación terminada');
    log('✔ Terminado: ${info.reparado.length} reparado(s), ${info.actualizado.length} actualizado(s), ${info.pendientes.length} pendiente(s)');
    return info;
  }

  // ======================================================================
  //  REPORTE, COMANDOS Y GUARDADO EN DESCARGAS
  // ======================================================================
  String _lineasAud(List<Hallazgo> l) => l.map((h) => '[${_etiquetaEstado(h.estado)}] ${h.modulo} · ${h.titulo}: ${h.detalle}').join('\n');

  String reporteTexto(InfoReparacion i) {
    final b = StringBuffer()
      ..writeln('REPORTE DE AUTOREPARACIÓN · $kNombreApp')
      ..writeln('Fecha: ${_fechaHora(i.fecha)}')
      ..writeln('')
      ..writeln('=== QUÉ SE REPARÓ EN EL TELÉFONO ===')
      ..writeln(i.reparado.isEmpty ? '(nada)' : i.reparado.map((x) => '• $x').join('\n'))
      ..writeln('')
      ..writeln('=== QUÉ SE ACTUALIZÓ A VERSIÓN MODERNA ===')
      ..writeln(i.actualizado.isEmpty ? '(nada)' : i.actualizado.map((x) => '• $x').join('\n'))
      ..writeln('')
      ..writeln('=== NO REPARADO EN EL TELÉFONO / REQUIERE COMPILACIÓN ===');
    if (i.pendientes.isEmpty) {
      b.writeln('(nada pendiente)');
    } else {
      for (final p in i.pendientes) {
        b
          ..writeln('• Módulo: ${p.modulo}')
          ..writeln('  Motivo: ${p.motivo}')
          ..writeln('  Acción para el flujo de trabajo (scripts/autoreparar_app.py): ${p.accion}  [clave: ${p.clave}]');
      }
    }
    b
      ..writeln('')
      ..writeln('=== AUDITORÍA INICIAL ===')
      ..writeln(_lineasAud(i.auditoriaInicial))
      ..writeln('')
      ..writeln('=== AUDITORÍA FINAL ===')
      ..writeln(_lineasAud(i.auditoriaFinal))
      ..writeln('')
      ..writeln('=== REGISTRO PASO A PASO ===')
      ..writeln(i.registro.join('\n'));
    return b.toString();
  }

  String reporteJson(InfoReparacion i) => const JsonEncoder.withIndent('  ').convert(<String, Object?>{
        'version': 1,
        'app': kNombreApp,
        'fecha': i.fecha.toIso8601String(),
        'idioma': gIdioma.value,
        'android': Platform.operatingSystemVersion,
        'pendientes': [
          for (final p in i.pendientes) <String, String>{'modulo': p.modulo, 'motivo': p.motivo, 'accion': p.accion, 'clave': p.clave}
        ],
        'paquetes_desactualizados': i.paquetes,
        'modelo_voz_actual': stt.rutaExterna == null ? kVoskUltimos['es'] : ruta_p.basename(stt.rutaExterna!),
        'modelos_voz_conocidos': kVoskUltimos,
        'reparado': i.reparado,
        'actualizado': i.actualizado,
      });

  String comandosTexto() => '''COMANDOS PARA APLICAR LO PENDIENTE (flujo de trabajo / PC con Python 3)

1) Copia estos archivos de Descargas a la carpeta scripts/ de tu repositorio:
     autoreparar_app.py
     reporte_autoreparacion.json
2) Sube los cambios al repositorio (el flujo de trabajo se ejecuta solo al subir):
     git add scripts/autoreparar_app.py scripts/reporte_autoreparacion.json
     git commit -m "Reporte de autoreparación"
     git push
3) En GitHub → Actions → «Build Android APK», el paso «5c. Autoreparación» ejecuta:
     python3 scripts/autoreparar_app.py --reporte scripts/reporte_autoreparacion.json
   y después compila el APK firmado. Instala el APK nuevo encima del actual (misma firma: no pierdes datos).

Para probar en una PC antes de subir (opcional):
     python3 scripts/autoreparar_app.py --reporte scripts/reporte_autoreparacion.json --simular
''';

  /// Guarda en Descargas: autoreparar_app.py, comandos, reporte (txt) y reporte (json).
  Future<List<String>> guardarKitReparacion(InfoReparacion i) async {
    final d = (await _carpetaDescarga(false, 'recorridos')).dir;
    final rutas = <String>[];
    Future<void> w(String nombre, String t) async {
      final f = File(ruta_p.join(d.path, nombre));
      await f.writeAsString(t);
      rutas.add(f.path);
    }
    await w('autoreparar_app.py', kScriptAutoreparar);
    await w('comandos_autoreparacion.txt', comandosTexto());
    await w('reporte_autoreparacion.txt', reporteTexto(i));
    await w('reporte_autoreparacion.json', reporteJson(i));
    return rutas;
  }

  /// Si el teléfono tiene Python (p. ej. Termux), ejecuta el script en modo simulación sobre el reporte guardado.
  Future<String> ejecutarPythonLocal(InfoReparacion i) async {
    final rutas = await guardarKitReparacion(i);
    final script = rutas.firstWhere((r) => r.endsWith('autoreparar_app.py'));
    final json = rutas.firstWhere((r) => r.endsWith('.json'));
    for (final exe in <String>['python3', 'python']) {
      try {
        final r = await Process.run(exe, [script, '--reporte', json, '--simular']).timeout(const Duration(seconds: 60));
        return '$exe terminó con código ${r.exitCode}\n${r.stdout}${r.stderr}';
      } catch (_) {}
    }
    return 'Este teléfono no tiene Python. Guardé autoreparar_app.py, los comandos y el reporte en Descargas; el flujo de trabajo los ejecutará al compilar.';
  }
}

// ============================================================================
//  PANTALLA DE DIAGNÓSTICO (auditoría + autoreparación)
// ============================================================================
class PantallaDiagnostico extends StatefulWidget {
  final Controlador c;
  const PantallaDiagnostico(this.c, {super.key});

  @override
  State<PantallaDiagnostico> createState() => _EstadoDiagnostico();
}

class _EstadoDiagnostico extends State<PantallaDiagnostico> {
  List<Hallazgo> _aud = <Hallazgo>[];
  String _tecnico = '';
  bool _cargando = true, _reparando = false;
  double _prog = 0;
  String _paso = '';
  final List<String> _log = <String>[];
  InfoReparacion? _info;
  final ScrollController _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    widget.c.addListener(_vigilar);
    _generar();
  }

  @override
  void dispose() {
    widget.c.removeListener(_vigilar);
    _scroll.dispose();
    super.dispose();
  }

  // Si el diagnóstico se oculta (3 toques en «Ajustes»), el panel se cierra solo
  void _vigilar() {
    if (!widget.c.diagnosticoVisible && mounted) Navigator.of(context).maybePop();
  }

  Future<void> _generar() async {
    setState(() => _cargando = true);
    List<Hallazgo> a;
    try {
      a = await widget.c.auditar().timeout(const Duration(seconds: 90));
    } catch (e) {
      a = <Hallazgo>[Hallazgo('Auditoría', 'No se pudo completar', EstadoAud.error, '$e')];
    }
    String t;
    try {
      t = await widget.c.diagnosticoSistema().timeout(const Duration(seconds: 40));
    } catch (e) {
      t = 'No se pudo generar el informe técnico: $e';
    }
    t = '$t\n\n=== REGISTRO DE EVENTOS Y ERRORES (lo más reciente al final) ===\n${Registro.texto()}';
    if (!mounted) return;
    setState(() {
      _aud = a;
      _tecnico = t;
      _cargando = false;
    });
  }

  Future<bool> _confirmar(String texto) async {
    final r = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Descargar actualización'),
        content: Text(texto),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Ahora no')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Descargar')),
        ],
      ),
    );
    return r == true;
  }

  Future<void> _reparar() async {
    setState(() {
      _reparando = true;
      _prog = 0;
      _log.clear();
      _info = null;
    });
    InfoReparacion? info;
    try {
      info = await widget.c.autorreparar(
        progreso: (p, t) {
          if (!mounted) return;
          setState(() {
            if (p >= 0) {
              _prog = p;
              _paso = t;
            } else {
              _log.add(t);
              if (_log.length > 300) _log.removeAt(0);
            }
          });
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
          });
        },
        confirmar: _confirmar,
      );
    } catch (e) {
      if (mounted) setState(() => _log.add('✖ Error inesperado: $e'));
    }
    if (!mounted) return;
    setState(() {
      _reparando = false;
      _info = info;
      if (info != null) _aud = info.auditoriaFinal;
    });
  }

  Widget _chip(EstadoAud e) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        decoration: BoxDecoration(color: _colorEstado(e), borderRadius: BorderRadius.circular(10)),
        child: Text(_etiquetaEstado(e), style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
      );

  @override
  Widget build(BuildContext context) {
    final c = widget.c;
    final info = _info;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Diagnóstico'),
        actions: [
          IconButton(onPressed: _cargando || _reparando ? null : _generar, icon: const Icon(Icons.refresh), tooltip: _tr('Actualizar')),
        ],
      ),
      body: _cargando
          ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              CircularProgressIndicator(),
              SizedBox(height: 12),
              Text('Revisando la aplicación…'),
            ]))
          : ListView(padding: const EdgeInsets.all(12), children: [
              Text(
                  '${_aud.where((h) => h.estado == EstadoAud.ok).length} OK · '
                  '${_aud.where((h) => h.estado == EstadoAud.desactualizado).length} desactualizado(s) · '
                  '${_aud.where((h) => h.estado == EstadoAud.advertencia).length} advertencia(s) · '
                  '${_aud.where((h) => h.estado == EstadoAud.error).length} error(es)',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              for (final h in _aud)
                Card(
                  margin: const EdgeInsets.only(bottom: 6),
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        _chip(h.estado),
                        const SizedBox(width: 8),
                        Expanded(child: Text('${h.modulo} · ${h.titulo}', style: const TextStyle(fontWeight: FontWeight.w600))),
                      ]),
                      const SizedBox(height: 4),
                      SelectableText(h.detalle, style: const TextStyle(fontSize: 12)),
                    ]),
                  ),
                ),
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: const Text('Informe técnico completo y registro'),
                children: [
                  SelectableText(_tecnico, style: const TextStyle(fontSize: 11)),
                  Row(children: [
                    Expanded(
                      child: FilledButton(
                        onPressed: () async {
                          await Clipboard.setData(ClipboardData(text: _tecnico));
                          if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Informe copiado')));
                        },
                        child: const Text('Copiar'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: OutlinedButton(onPressed: () => c.guardarDiagnostico(_tecnico), child: const Text('Guardar en Descargas'))),
                  ]),
                ],
              ),
              const Divider(),
              // ---------------- AUTOREPARACIÓN (hasta abajo) ----------------
              const Text('Autoreparación', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              const Text(
                  'Reengancha el mapa, limpia cachés, reconstruye el índice, reescanea Descargas y microSD, descomprime .zip y revisa el modelo de voz. No borra tus lugares, rutas ni historial.',
                  style: TextStyle(fontSize: 12)),
              const SizedBox(height: 8),
              FilledButton.icon(
                onPressed: _reparando ? null : _reparar,
                icon: const Icon(Icons.build_circle_outlined),
                label: const Text('Autoreparación'),
              ),
              if (_reparando || _log.isNotEmpty) ...[
                const SizedBox(height: 8),
                LinearProgressIndicator(value: _reparando ? (_prog <= 0 ? null : _prog) : 1.0),
                const SizedBox(height: 4),
                Text(_paso, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                Container(
                  height: 170,
                  margin: const EdgeInsets.only(top: 6),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(8)),
                  child: ListView(controller: _scroll, children: [
                    for (final l in _log) Text(l, style: const TextStyle(color: Colors.greenAccent, fontSize: 11, fontFamily: 'monospace')),
                  ]),
                ),
              ],
              if (info != null) ...[
                const SizedBox(height: 10),
                const Text('Qué se reparó en el teléfono', style: TextStyle(fontWeight: FontWeight.bold)),
                if (info.reparado.isEmpty) const Text('(nada)') else for (final x in info.reparado) Text('• $x', style: const TextStyle(fontSize: 12)),
                const SizedBox(height: 6),
                const Text('Qué se actualizó a versión moderna', style: TextStyle(fontWeight: FontWeight.bold)),
                if (info.actualizado.isEmpty) const Text('(nada)') else for (final x in info.actualizado) Text('• $x', style: const TextStyle(fontSize: 12)),
                const SizedBox(height: 6),
                const Text('NO REPARADO EN EL TELÉFONO / REQUIERE COMPILACIÓN',
                    style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFC62828))),
                if (info.pendientes.isEmpty)
                  const Text('(nada pendiente)')
                else
                  for (final p in info.pendientes)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: SelectableText('• ${p.modulo}: ${p.motivo}\n   → ${p.accion}', style: const TextStyle(fontSize: 12)),
                    ),
                const SizedBox(height: 8),
                FilledButton.tonalIcon(
                  icon: const Icon(Icons.save_alt),
                  label: const Text('Guardar script, comandos y reporte en Descargas'),
                  onPressed: () async {
                    try {
                      final r = await c.guardarKitReparacion(info);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Guardado en ${ruta_p.dirname(r.first)}: ${r.map(ruta_p.basename).join(', ')}'), duration: const Duration(seconds: 8)));
                      }
                    } catch (e) {
                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo guardar: $e')));
                    }
                  },
                ),
                const SizedBox(height: 6),
                OutlinedButton.icon(
                  icon: const Icon(Icons.terminal),
                  label: const Text('Ejecutar con Python local (si existe)'),
                  onPressed: () async {
                    final t = await c.ejecutarPythonLocal(info);
                    if (!context.mounted) return;
                    await showDialog<void>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Python local'),
                        content: SingleChildScrollView(child: SelectableText(t, style: const TextStyle(fontSize: 12))),
                        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cerrar'))],
                      ),
                    );
                  },
                ),
                const SizedBox(height: 6),
                OutlinedButton.icon(
                  icon: const Icon(Icons.copy),
                  label: const Text('Copiar reporte completo'),
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: c.reporteTexto(info)));
                    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Reporte copiado')));
                  },
                ),
              ],
              const SizedBox(height: 24),
            ]),
    );
  }
}
