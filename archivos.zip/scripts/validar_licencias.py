#!/usr/bin/env python3
"""Revisa la licencia de TODAS las dependencias (directas y transitivas) usando .dart_tool/package_config.json.
Falla (código 1) si encuentra una licencia que obligaría a abrir tu código (GPL/AGPL/SSPL) o que prohíbe uso comercial.
Avisa con LGPL/MPL/EPL (copyleft débil: normalmente permitido al usar como librería, pero hay que cumplir sus condiciones)."""
import json, os, re, sys
from urllib.parse import unquote, urlparse

FUERTE = [(r'GNU AFFERO', 'AGPL'), (r'GNU GENERAL PUBLIC LICENSE', 'GPL'), (r'SERVER SIDE PUBLIC LICENSE', 'SSPL'),
          (r'NON-?COMMERCIAL|NO COMERCIAL|NOT FOR COMMERCIAL', 'No comercial'), (r'BUSINESS SOURCE LICENSE', 'BSL')]
DEBIL = [(r'GNU LESSER GENERAL PUBLIC', 'LGPL'), (r'MOZILLA PUBLIC LICENSE', 'MPL'), (r'ECLIPSE PUBLIC LICENSE', 'EPL')]
PERMISIVA = [(r'APACHE LICENSE', 'Apache-2.0'), (r'\bMIT LICENSE|PERMISSION IS HEREBY GRANTED, FREE OF CHARGE', 'MIT'),
             (r'REDISTRIBUTION AND USE IN SOURCE AND BINARY FORMS', 'BSD'), (r'\bISC LICENSE|PERMISSION TO USE, COPY, MODIFY, AND/OR DISTRIBUTE', 'ISC'),
             (r'\bZLIB', 'zlib'), (r'THE UNLICENSE|PUBLIC DOMAIN', 'Dominio público')]

def clasifica(t):
    u = t.upper()
    for rx, n in FUERTE:
        if re.search(rx, u):
            # una licencia permisiva puede MENCIONAR la GPL (p. ej. cláusula de compatibilidad): solo cuenta si no hay texto permisivo
            if not any(re.search(r2, u) for r2, _ in PERMISIVA): return 'FUERTE', n
    for rx, n in DEBIL:
        if re.search(rx, u): return 'DEBIL', n
    nombres = [n for rx, n in PERMISIVA if re.search(rx, u)]
    if nombres: return 'OK', '/'.join(nombres)
    return 'DESCONOCIDA', '?'

def main():
    pc = '.dart_tool/package_config.json'
    if not os.path.isfile(pc): print('✘ falta ' + pc + ' (¿corriste flutter pub get?)'); return 1
    cfg = json.load(open(pc, encoding='utf-8'))
    base = os.path.dirname(os.path.abspath(pc))
    filas, malos, avisos = [], 0, 0
    for p in sorted(cfg['packages'], key=lambda x: x['name']):
        nombre = p['name']
        if nombre in ('navegacion_offline_mx', 'sky_engine', 'flutter', 'flutter_test', 'flutter_lints', 'flutter_web_plugins'): continue
        uri = p['rootUri']
        ruta = unquote(urlparse(uri).path) if uri.startswith('file:') else os.path.normpath(os.path.join(base, uri))
        lic = ''
        for f in ('LICENSE', 'LICENSE.md', 'LICENSE.txt', 'LICENCE', 'COPYING', 'license'):
            fp = os.path.join(ruta, f)
            if os.path.isfile(fp): lic = open(fp, encoding='utf-8', errors='replace').read(); break
        if not lic: filas.append((nombre, 'SIN ARCHIVO', '⚠')); avisos += 1; continue
        k, n = clasifica(lic)
        marca = {'OK': '✔', 'DEBIL': '⚠', 'DESCONOCIDA': '⚠', 'FUERTE': '✘'}[k]
        if k == 'FUERTE': malos += 1
        elif k != 'OK': avisos += 1
        filas.append((nombre, n, marca))
    print('LICENCIAS DE DEPENDENCIAS')
    for n, l, m in filas: print(f'  {m} {n:<34} {l}')
    print(f'\nRESUMEN: {sum(1 for f in filas if f[2]=="✔")} permisivas · {avisos} para revisar · {malos} PROBLEMAS')
    if malos: print('✘ Hay licencias que podrían obligarte a abrir el código o impedir uso comercial. Reemplaza esos paquetes.')
    return 1 if malos else 0

if __name__ == '__main__': sys.exit(main())
