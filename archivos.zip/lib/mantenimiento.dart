// ============================================================================
// MANTENIMIENTO: revisión cada 90 días (con notificación local discreta) y administrador de archivos descargados
// (parte de main.dart: comparte lo privado)
// ============================================================================
part of 'main.dart';

final notif.FlutterLocalNotificationsPlugin _plugNotif = notif.FlutterLocalNotificationsPlugin();
bool _notifIniciado = false;

Future<void> _iniciarNotificaciones() async {
  if (_notifIniciado) return;
  try {
    await _plugNotif.initialize(const notif.InitializationSettings(android: notif.AndroidInitializationSettings('@mipmap/ic_launcher')));
    _notifIniciado = true;
  } catch (e) {
    Registro.anotar('No se pudo iniciar las notificaciones: $e');
  }
}

/// Notificación local discreta (importancia baja, sin sonido).
Future<void> mostrarNotificacionRevision(String titulo, String cuerpo) async {
  try {
    await _iniciarNotificaciones();
    if (!_notifIniciado) return;
    await _plugNotif.show(
      7001,
      titulo,
      cuerpo,
      const notif.NotificationDetails(
        android: notif.AndroidNotificationDetails(
          'revision_archivos',
          'Revisión de archivos',
          channelDescription: 'Aviso discreto cada 3 meses para actualizar mapas, red vial y voz',
          importance: notif.Importance.low,
          priority: notif.Priority.low,
          playSound: false,
          enableVibration: false,
        ),
      ),
    );
  } catch (e) {
    Registro.anotar('No se pudo mostrar la notificación: $e');
  }
}

class RecursoViejo {
  final String tipo, nombre, motivo;
  const RecursoViejo(this.tipo, this.nombre, this.motivo);
}

class ArchivoGestion {
  final String nombre, ruta, ubicacion;
  final int bytes;
  final DateTime fecha;
  final bool enUso, esCarpeta;
  const ArchivoGestion(this.nombre, this.ruta, this.ubicacion, this.bytes, this.fecha, this.enUso, this.esCarpeta);
}

extension MantenimientoControlador on Controlador {
  void cargarAjustesMantenimiento(Map m) {
    ultimaRevisionMs = (m['ultimaRevisionMs'] as num?)?.toInt() ?? 0;
    posponerHastaMs = (m['posponerHastaMs'] as num?)?.toInt() ?? 0;
    proximoAvisoMs = (m['proximoAvisoMs'] as num?)?.toInt() ?? 0;
  }

  Map<String, Object?> ajustesMantenimiento() => <String, Object?>{
        'ultimaRevisionMs': ultimaRevisionMs,
        'posponerHastaMs': posponerHastaMs,
        'proximoAvisoMs': proximoAvisoMs,
      };

  /// Recursos activos con más de 3 meses o con modelo de voz más moderno disponible.
  Future<List<RecursoViejo>> recursosParaRevisar() async {
    final r = <RecursoViejo>[];
    final ahora = DateTime.now();
    try {
      for (final m in mapasDisponiblesLista.where((m) => m.nombre == mapaActivo)) {
        final d = ahora.difference(File(m.ruta).statSync().modified).inDays;
        if (d > kDiasRevision) r.add(RecursoViejo('Mapa', m.nombre, 'tiene $d días'));
      }
      for (final f in redesDisponiblesLista.where((f) => ruta_p.basename(f.path) == redActiva)) {
        final d = ahora.difference(f.statSync().modified).inDays;
        if (d > kDiasRevision) r.add(RecursoViejo('Red vial y lugares', ruta_p.basename(f.path), 'tiene $d días'));
      }
      final ext = stt.rutaExterna;
      final ult = kVoskUltimos[gIdioma.value] ?? kVoskUltimos['es']!;
      if (ext != null) {
        final nombre = ruta_p.basename(ext);
        final prefijo = ult.replaceAll(RegExp(r'-\d+(\.\d+)*$'), '');
        if (nombre.startsWith(prefijo) &&
            _comparaVersion(_versionDe(nombre.substring(prefijo.length)), _versionDe(ult.substring(prefijo.length))) < 0) {
          r.add(RecursoViejo('Voz', nombre, 'hay un modelo más moderno: $ult'));
        } else {
          final d = ahora.difference(Directory(ext).statSync().modified).inDays;
          if (d > kDiasRevision && !nombre.startsWith(prefijo)) r.add(RecursoViejo('Voz', nombre, 'tiene $d días; sugerido para tu idioma: $ult'));
        }
      }
    } catch (_) {}
    return r;
  }

  /// Se llama al abrir la app. Cada 90 días: si algo está viejo, notificación discreta y vista para actualizar o posponer.
  Future<void> revisarTrimestral() async {
    final ahora = DateTime.now().millisecondsSinceEpoch;
    if (ultimaRevisionMs == 0) {
      ultimaRevisionMs = ahora; // primera vez: empieza a contar, sin molestar
      await _guardarAjustes();
      return;
    }
    if (ahora < posponerHastaMs || ahora < proximoAvisoMs) return;
    if (ahora - ultimaRevisionMs < kDiasRevision * 86400000) return;
    final viejos = await recursosParaRevisar();
    if (viejos.isEmpty) {
      ultimaRevisionMs = ahora; // todo vigente: la próxima revisión es en 3 meses
      await _guardarAjustes();
      return;
    }
    proximoAvisoMs = ahora + 7 * 86400000; // no se repite el aviso en los próximos 7 días
    await _guardarAjustes();
    await mostrarNotificacionRevision('Revisión de tus archivos offline',
        '${viejos.length} recurso(s) con más de 3 meses. Ábrela para actualizar o posponer.');
    revisionParaMostrar = viejos;
    notifyListeners();
  }

  Future<void> posponerRevision90() async {
    final ahora = DateTime.now().millisecondsSinceEpoch;
    ultimaRevisionMs = ahora;
    posponerHastaMs = ahora + kDiasRevision * 86400000;
    await _guardarAjustes();
  }

  Future<void> revisionHecha() async {
    ultimaRevisionMs = DateTime.now().millisecondsSinceEpoch;
    await _guardarAjustes();
  }

  // ---------------------------------------------------- gestor de archivos
  static const List<String> _extGestion = <String>['.mbtiles', '.geojson', '.zip', '.part'];
  static const Set<String> _nombresGestion = <String>{
    'autoreparar_app.py',
    'comandos_autoreparacion.txt',
    'reporte_autoreparacion.txt',
    'reporte_autoreparacion.json',
    'diagnostico_navegacion.txt',
  };

  Future<int> _tamanoCarpeta(Directory d) async {
    var t = 0;
    try {
      await for (final e in d.list(recursive: true, followLinks: false)) {
        if (e is File) t += e.lengthSync();
      }
    } catch (_) {}
    return t;
  }

  Future<List<ArchivoGestion>> listarArchivosGestion() async {
    final r = <ArchivoGestion>[];
    final vistos = <String>{};
    if (!await _tienePermisoDescargas()) return r;
    for (final sd in <bool>[false, true]) {
      final ubic = sd ? 'Tarjeta microSD' : 'Descargas';
      try {
        final fs = await _archivosExternos(sd, (p) {
          final b = ruta_p.basename(p).toLowerCase();
          return _extGestion.any(b.endsWith) || _nombresGestion.contains(b);
        });
        for (final f in fs) {
          if (!vistos.add(f.path)) continue;
          final b = ruta_p.basename(f.path);
          final st = f.statSync();
          final enUso = (b == mapaActivo && b.toLowerCase().endsWith('.mbtiles')) ||
              (b == redActiva && b.toLowerCase().endsWith('.geojson') && !Controlador.esClipping(b));
          r.add(ArchivoGestion(b, f.path, ubic, st.size, st.modified, enUso, false));
        }
      } catch (_) {}
    }
    try {
      for (final d in await modelosVozInstalados()) {
        if (!vistos.add(d.path)) continue;
        final ubic = d.path.startsWith('/storage/emulated/0')
            ? 'Descargas'
            : (d.path.startsWith('/storage/') ? 'Tarjeta microSD' : 'Memoria de la app');
        if (ubic == 'Memoria de la app') continue; // lo interno no se administra aquí
        r.add(ArchivoGestion(ruta_p.basename(d.path), d.path, ubic, await _tamanoCarpeta(d), d.statSync().modified,
            stt.rutaExterna == d.path, true));
      }
    } catch (_) {}
    r.sort((a, b) {
      if (a.enUso != b.enUso) return a.enUso ? -1 : 1;
      return b.fecha.compareTo(a.fecha);
    });
    return r;
  }

  /// Borra los archivos elegidos y devuelve los bytes liberados. Si se borra algo en uso, se desactiva limpiamente.
  Future<int> borrarArchivosGestion(List<ArchivoGestion> lista) async {
    var liberado = 0;
    var tocoMapa = false, tocoRed = false, tocoVoz = false;
    for (final a in lista) {
      try {
        if (a.esCarpeta) {
          await Directory(a.ruta).delete(recursive: true);
          if (a.enUso) tocoVoz = true;
        } else {
          await File(a.ruta).delete();
          if (a.enUso && a.nombre.toLowerCase().endsWith('.mbtiles')) tocoMapa = true;
          if (a.enUso && a.nombre.toLowerCase().endsWith('.geojson')) tocoRed = true;
        }
        liberado += a.bytes;
      } catch (e) {
        _msg('No se pudo borrar ${a.nombre}: $e');
      }
    }
    if (tocoVoz) await establecerModeloVoz('');
    if (tocoMapa) {
      mapaActivo = '';
      await _abrirMapas();
    }
    if (tocoRed) {
      redActiva = '';
      motor.red = null;
      redCargada = false;
      _ventanaRed = null;
      _indicesCalles.clear();
      await _cargarRedGuardada();
    }
    await _guardarAjustes();
    notifyListeners();
    return liberado;
  }
}

// ============================================================================
//  Vista de la revisión trimestral
// ============================================================================
Future<void> mostrarRevisionTrimestral(BuildContext context, Controlador c, List<RecursoViejo> viejos) async {
  final r = await showDialog<String>(
    context: context,
    barrierDismissible: true,
    builder: (ctx) => AlertDialog(
      title: const Text('Revisión de tus archivos (cada 3 meses)'),
      content: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          const Text('Estos recursos activos están viejos o tienen una versión más moderna:'),
          const SizedBox(height: 8),
          for (final v in viejos) Text('• ${v.tipo}: ${v.nombre} (${v.motivo})', style: const TextStyle(fontSize: 13)),
          const SizedBox(height: 8),
          const Text('Puedes exportar archivos nuevos en Ajustes (HOT Export) sin borrar los actuales; después elígelos con el botón de capas.',
              style: TextStyle(fontSize: 12)),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, 'posponer'), child: const Text('Posponer 90 días')),
        FilledButton(onPressed: () => Navigator.pop(ctx, 'actualizar'), child: const Text('Actualizar')),
      ],
    ),
  );
  if (r == 'posponer') {
    await c.posponerRevision90();
  } else if (r == 'actualizar') {
    await c.revisionHecha();
    if (context.mounted) {
      await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => PantallaMenu(c, 5)));
    }
  }
}

// ============================================================================
//  Administrar y limpiar archivos descargados
// ============================================================================
class PantallaLimpieza extends StatefulWidget {
  final Controlador c;
  const PantallaLimpieza(this.c, {super.key});

  @override
  State<PantallaLimpieza> createState() => _EstadoLimpieza();
}

class _EstadoLimpieza extends State<PantallaLimpieza> {
  List<ArchivoGestion> _lista = <ArchivoGestion>[];
  final Set<String> _sel = <String>{};
  bool _cargando = true;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    setState(() => _cargando = true);
    final l = await widget.c.listarArchivosGestion();
    if (!mounted) return;
    setState(() {
      _lista = l;
      _sel.removeWhere((p) => !l.any((a) => a.ruta == p));
      _cargando = false;
    });
  }

  Future<void> _borrar() async {
    final elegidos = _lista.where((a) => _sel.contains(a.ruta)).toList();
    if (elegidos.isEmpty) return;
    final total = elegidos.fold<int>(0, (s, a) => s + a.bytes);
    final enUso = elegidos.where((a) => a.enUso).toList();
    var ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('¿Borrar archivos?'),
        content: Text('Se borrarán ${elegidos.length} elemento(s) (${_tamano(total)}). No se puede deshacer.\n\n${elegidos.map((a) => '• ${a.nombre} (${a.ubicacion})').join('\n')}'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Borrar')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    if (enUso.isNotEmpty) {
      ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          icon: const Icon(Icons.warning_amber_rounded, color: Color(0xFFC62828), size: 40),
          title: const Text('¡Estás borrando algo EN USO!'),
          content: Text('${enUso.map((a) => '• ${a.nombre}').join('\n')}\n\nLa app dejará de usarlo ahora mismo (sin mapa, red vial o voz hasta que elijas otro archivo).'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Mejor no')),
            FilledButton(
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFFC62828)),
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Borrar de todos modos')),
          ],
        ),
      );
      if (ok != true || !mounted) return;
    }
    final liberado = await widget.c.borrarArchivosGestion(elegidos);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Espacio liberado: ${_tamano(liberado)}')));
    _sel.clear();
    await _cargar();
  }

  @override
  Widget build(BuildContext context) {
    final totalSel = _lista.where((a) => _sel.contains(a.ruta)).fold<int>(0, (s, a) => s + a.bytes);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Administrar y limpiar archivos descargados'),
        actions: [IconButton(onPressed: _cargando ? null : _cargar, icon: const Icon(Icons.refresh))],
      ),
      body: _cargando
          ? const Center(child: CircularProgressIndicator())
          : _lista.isEmpty
              ? const Padding(padding: EdgeInsets.all(16), child: Text('No encontré archivos de la app en Descargas ni en la tarjeta microSD (¿falta el permiso de archivos?).'))
              : Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                    child: Row(children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => setState(() {
                            _sel
                              ..clear()
                              ..addAll(_lista.where((a) => !a.enUso).map((a) => a.ruta));
                          }),
                          child: const Text('Seleccionar viejos / no usados'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      TextButton(onPressed: () => setState(_sel.clear), child: const Text('Ninguno')),
                    ]),
                  ),
                  Expanded(
                    child: ListView.separated(
                      itemCount: _lista.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final a = _lista[i];
                        return CheckboxListTile(
                          value: _sel.contains(a.ruta),
                          onChanged: (v) => setState(() => v == true ? _sel.add(a.ruta) : _sel.remove(a.ruta)),
                          secondary: Icon(a.esCarpeta ? Icons.record_voice_over_outlined : (a.nombre.toLowerCase().endsWith('.mbtiles') ? Icons.map_outlined : Icons.insert_drive_file_outlined)),
                          title: Text(a.nombre, maxLines: 2, overflow: TextOverflow.ellipsis),
                          subtitle: Text('${a.ubicacion} · ${_tamano(a.bytes)} · ${_fechaHora(a.fecha)}\n${a.enUso ? 'En uso' : 'Viejo / No usado'}',
                              style: TextStyle(color: a.enUso ? const Color(0xFF2E7D32) : const Color(0xFFEF6C00), fontWeight: FontWeight.w600)),
                          isThreeLine: true,
                        );
                      },
                    ),
                  ),
                  SafeArea(
                    top: false,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
                      child: SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: _sel.isEmpty ? null : _borrar,
                          icon: const Icon(Icons.delete_outline),
                          label: Text(_sel.isEmpty ? 'Borrar seleccionados' : 'Borrar ${_sel.length} (${_tamano(totalSel)})'),
                        ),
                      ),
                    ),
                  ),
                ]),
    );
  }
}
